// constants.tsx
import React from 'react';
// FIX: Import missing type definitions from `types.ts`.
import { AiChatMessage, CustomerTechMessage, DeliveryPerson, ServiceJob, SparePart, TechChatMessage, Technician } from './types';

export const GEMINI_MODEL = 'gemini-2.5-flash';

// --- MOCK DATA ---

export const MOCK_TECHNICIANS: Technician[] = [
  {
    id: 'tech-1',
    name: 'Ali Hassan',
    photoUrl: 'https://i.pravatar.cc/150?u=ali',
    distance: '2.1km',
    eta: '8 mins',
    rating: 4.8,
    specialization: 'AC Repair',
    vehicleType: 'Toyota Hiace',
    badgeNumber: 'DXB-T786',
    skills: ['Compressor Repair', 'Gas Refilling', 'Duct Cleaning'],
    experience: 8,
    serviceArea: 'Dubai Marina, JLT, Palm Jumeirah',
    reviews: [{ author: 'Sara K.', comment: 'Very professional and quick!', rating: 5 }],
    rewards: { points: 1250, level: 'Gold' },
  },
  {
    id: 'tech-2',
    name: 'Ben Carter',
    photoUrl: 'https://i.pravatar.cc/150?u=ben',
    distance: '3.5km',
    eta: '12 mins',
    rating: 4.9,
    specialization: 'Electrical',
    vehicleType: 'Ford Transit',
    badgeNumber: 'DXB-T452',
    skills: ['Wiring', 'Fixture Installation', 'Panel Upgrades'],
    experience: 12,
    serviceArea: 'Downtown Dubai, Business Bay',
    reviews: [{ author: 'Mike L.', comment: 'Found the issue in minutes. Highly recommended.', rating: 5 }],
    rewards: { points: 850, level: 'Silver' },
  },
  {
    id: 'tech-3',
    name: 'Fatima Ahmed',
    photoUrl: 'https://i.pravatar.cc/150?u=fatima',
    distance: '4.2km',
    eta: '15 mins',
    rating: 4.7,
    specialization: 'Plumbing',
    vehicleType: 'Nissan Urvan',
    badgeNumber: 'SHJ-T119',
     skills: ['Leak Detection', 'Pipe Fitting', 'Drain Unclogging'],
    experience: 6,
    serviceArea: 'Deira, Bur Dubai',
    reviews: [{ author: 'David C.', comment: 'Fixed my leaky pipe perfectly.', rating: 4.5 }],
    rewards: { points: 2400, level: 'Platinum' },
  },
   {
    id: 'tech-4',
    name: 'John Pinto',
    photoUrl: 'https://i.pravatar.cc/150?u=john',
    distance: '1.8km',
    eta: '7 mins',
    rating: 4.9,
    specialization: 'Vehicle Maintenance',
    vehicleType: 'Ford F-150',
    badgeNumber: 'DXB-V551',
    skills: ['Oil Change', 'Filter Replacement', 'Brake Inspection'],
    experience: 15,
    serviceArea: 'Al Quoz, Al Barsha',
    reviews: [{ author: 'Emily R.', comment: 'Super fast oil change at my home!', rating: 5 }],
    rewards: { points: 3100, level: 'Platinum' },
  },
];

export const MOCK_DELIVERY_PEOPLE: DeliveryPerson[] = [
    {
        id: 'del-1',
        name: 'Samir Khan',
        photoUrl: 'https://i.pravatar.cc/150?u=samir',
        vehicleType: 'Motorbike',
        rating: 4.9,
    },
    {
        id: 'del-2',
        name: 'Chen Wei',
        photoUrl: 'https://i.pravatar.cc/150?u=chen',
        vehicleType: 'Van',
        rating: 4.7,
    },
];

export const MOCK_SPARE_PARTS: SparePart[] = [
    {
        id: 'part-1',
        name: 'AC Compressor 1.5 Ton',
        imageUrl: 'https://via.placeholder.com/150/FFC107/000000?Text=AC+Compressor',
        serialNumber: 'ACF-A12-001',
        availability: [
            { partnerId: 'partner-1', partnerName: 'XYZ Auto Parts', partnerLocation: 'Dubai', stock: 5, price: 450 },
            { partnerId: 'partner-2', partnerName: 'Quick Parts Intl', partnerLocation: 'Sharjah', stock: 2, price: 460 }
        ]
    },
    {
        id: 'part-2',
        name: 'Thermostat Digital XY-2',
        imageUrl: 'https://via.placeholder.com/150/00BCD4/000000?Text=Thermostat',
        serialNumber: 'TH-DXY-002',
        availability: [
            { partnerId: 'partner-1', partnerName: 'XYZ Auto Parts', partnerLocation: 'Dubai', stock: 0, price: 120 },
            { partnerId: 'partner-2', partnerName: 'Quick Parts Intl', partnerLocation: 'Sharjah', stock: 10, price: 115 }
        ]
    },
    {
        id: 'part-3',
        name: 'Engine Oil Filter 5L',
        imageUrl: 'https://via.placeholder.com/150/4CAF50/000000?Text=Oil+Filter',
        serialNumber: 'EOF-5L-003',
        availability: [
            { partnerId: 'partner-1', partnerName: 'XYZ Auto Parts', partnerLocation: 'Dubai', stock: 25, price: 45 },
        ]
    },
    {
        id: 'part-4',
        name: '1/2" Copper Pipe (Meter)',
        imageUrl: 'https://via.placeholder.com/150/F44336/000000?Text=Copper+Pipe',
        serialNumber: 'CPP-HIN-004',
        availability: [
            { partnerId: 'partner-2', partnerName: 'Quick Parts Intl', partnerLocation: 'Sharjah', stock: 150, price: 25 },
        ]
    },
    {
        id: 'part-5',
        name: 'Brake Pad Set - Ceramic',
        serialNumber: 'BPS-C-005',
        imageUrl: 'https://via.placeholder.com/150/9C27B0/000000?Text=Brake+Pads',
        availability: [
             { partnerId: 'partner-1', partnerName: 'XYZ Auto Parts', partnerLocation: 'Dubai', stock: 0, price: 250 },
             { partnerId: 'partner-2', partnerName: 'Quick Parts Intl', partnerLocation: 'Sharjah', stock: 8, price: 240 }
        ]
    }
];

export const MOCK_TECHNICIAN_JOBS: ServiceJob[] = [
    {
        id: 'job-123',
        customerName: 'Aisha Al-Futtaim',
        serviceType: 'AC Repair',
        problemSummary: "AC is not cooling and making a strange noise.",
        location: 'Al Barsha, Dubai',
        status: 'Inspection',
        technicianId: 'tech-1',
        requestTime: '10:30 AM',
        partOrderIds: [],
        partsReceived: false,
    }
];

export const MOCK_AI_CONVERSATION: AiChatMessage[] = [
    { sender: 'ai', text: "Hello! I'm your Zerpi AI assistant. How can I help you today? You can type, send a voice note, or upload an image/video of the issue." }
];

export const MOCK_TECH_CHAT: TechChatMessage[] = [
    { senderId: 'tech-2', senderName: 'Ben Carter', text: "Hey team, has anyone worked on a flickering issue with new LED fixtures from brand X? Can't seem to isolate the cause.", timestamp: '10:45 AM'},
    { senderId: 'tech-3', senderName: 'Fatima Ahmed', text: "Ben, check the dimmer switch compatibility. Brand X LEDs are picky. Had a similar issue last week.", timestamp: '10:47 AM'},
];

export const MOCK_CUSTOMER_TECH_CHAT: CustomerTechMessage[] = [
    { sender: 'customer', text: "Hi, just wanted to check if you're nearby?", timestamp: '11:05 AM'},
    { sender: 'technician', text: "Yes, I'm about 10 minutes away. I'll send a notification when I arrive.", timestamp: '11:06 AM'},
];


// --- ICONS ---

export const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z" clipRule="evenodd" />
  </svg>
);
export const WrenchScrewdriverIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M12 6.75a5.25 5.25 0 0 1 5.25 5.25c0 1.525-.626 2.902-1.645 3.883a.75.75 0 0 0-.263 1.323l3.101 3.101-1.06 1.06-3.102-3.101a.75.75 0 0 0-1.323.263A5.233 5.233 0 0 1 12 17.25a5.25 5.25 0 0 1-5.25-5.25A5.25 5.25 0 0 1 12 6.75Zm-6.14-3.493a.75.75 0 0 1 .106-.023l3.493-1.164a.75.75 0 0 1 .956.956L8.12 6.977a.75.75 0 0 1-1.082-1.082l2.39-2.39-1.992.664-2.8-2.8a.75.75 0 0 1-.024.106Zm3.182 8.162c.024.316.024.638 0 .954l4.53 1.294a.75.75 0 0 1 .597.891l-.659 2.305a.75.75 0 0 1-1.442-.412l.504-1.763-3.743-1.069a5.228 5.228 0 0 1-1.382-1.382l-1.07-3.743-1.763.504a.75.75 0 0 1-.412-1.442l2.305-.659a.75.75 0 0 1 .891.597l1.294 4.53Z" clipRule="evenodd" />
  </svg>
);
export const BuildingStorefrontIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M11.25 3.099A5.25 5.25 0 0 0 6.75 7.5v1.562A5.235 5.235 0 0 0 3.127 13.5H3a.75.75 0 0 0 0 1.5h.127a5.235 5.235 0 0 0 3.623 4.438V21a.75.75 0 0 0 1.5 0v-1.562a5.235 5.235 0 0 0 3.623-4.438h10.25a.75.75 0 0 0 0-1.5H11.873A5.235 5.235 0 0 0 8.25 9.062V7.5a3.75 3.75 0 0 1 3-3.661Z" />
    <path d="M14.623 2.146a.75.75 0 0 1 .848-.204l.829.399a.75.75 0 0 1 .425.658V3a3 3 0 0 1 3 3v1.5a.75.75 0 0 1-1.5 0V6a1.5 1.5 0 0 0-1.5-1.5h-.056a.75.75 0 0 1-.658-.425l-.4-.828a.75.75 0 0 1-.203-.848Z" />
  </svg>
);
export const TruckIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M3.375 4.5C2.339 4.5 1.5 5.34 1.5 6.375V13.5h12V6.375c0-1.036-.84-1.875-1.875-1.875h-8.25ZM13.5 15h-12v2.625c0 1.035.84 1.875 1.875 1.875h.375a3 3 0 1 1 5.25 0h1.75a3 3 0 1 1 5.25 0h.375c1.035 0 1.875-.84 1.875-1.875V15h-6.75Z" />
    <path d="M22.5 9h-6.75v10.5h4.125a2.625 2.625 0 0 0 2.625-2.625V9Z" />
  </svg>
);
export const StarIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.006Z" clipRule="evenodd" />
  </svg>
);
export const ArrowLeftIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M7.72 12.53a.75.75 0 0 1 0-1.06l7.5-7.5a.75.75 0 1 1 1.06 1.06L9.31 12l6.97 6.97a.75.75 0 1 1-1.06 1.06l-7.5-7.5Z" clipRule="evenodd" />
  </svg>
);
export const MagnifyingGlassIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clipRule="evenodd" />
  </svg>
);
export const PaperAirplaneIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M12 15a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5A.75.75 0 0 1 12 15Zm0-4a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5A.75.75 0 0 1 12 11Zm0-4a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5A.75.75 0 0 1 12 7ZM4.502 21.033a.75.75 0 0 1-.84-.22l-1.332-1.664a.75.75 0 0 1 .22-.84l19.5-12.5a.75.75 0 0 1 .986.986l-12.5 19.5a.75.75 0 0 1-.62.339Z" />
  </svg>
);
export const CameraIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M1.5 6a2.25 2.25 0 0 1 2.25-2.25h16.5A2.25 2.25 0 0 1 22.5 6v12a2.25 2.25 0 0 1-2.25-2.25H3.75A2.25 2.25 0 0 1 1.5 18V6ZM3 16.06l2.76-2.76a.75.75 0 0 1 1.06 0l3.75 3.75a.75.75 0 0 0 1.06 0l2.5-2.5a.75.75 0 0 1 1.06 0l4.25 4.25V6H3v10.06Z" clipRule="evenodd" />
  </svg>
);
export const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M12 3.75a.75.75 0 0 1 .75.75v6.75h6.75a.75.75 0 0 1 0 1.5h-6.75v6.75a.75.75 0 0 1-1.5 0v-6.75H4.5a.75.75 0 0 1 0-1.5h6.75V4.5a.75.75 0 0 1 .75-.75Z" clipRule="evenodd" />
  </svg>
);
export const CheckCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.36-1.814a.75.75 0 1 0-1.06-1.06l-3.25 3.25-1.5-1.5a.75.75 0 0 0-1.06 1.06l2 2a.75.75 0 0 0 1.06 0l3.75-3.75Z" clipRule="evenodd" />
    </svg>
);
export const ClockIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 6a.75.75 0 0 0-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 0 0 0-1.5h-3.75V6Z" clipRule="evenodd" />
    </svg>
);
export const CogIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12 9a3.75 3.75 0 1 0 0 7.5A3.75 3.75 0 0 0 12 9Zm-2.625 3.75a2.625 2.625 0 1 1 5.25 0 2.625 2.625 0 0 1-5.25 0Z" />
        <path fillRule="evenodd" d="M12 1.5a.75.75 0 0 1 .75.75V3a.75.75 0 0 1-1.5 0V2.25A.75.75 0 0 1 12 1.5ZM12 21a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 12 21ZM3.754 6.22a.75.75 0 0 1 1.06 0l1.061 1.06a.75.75 0 0 1-1.06 1.06l-1.06-1.06a.75.75 0 0 1 0-1.06ZM18.126 18.126a.75.75 0 0 1 1.06 0l1.061 1.06a.75.75 0 0 1-1.06 1.06l-1.06-1.06a.75.75 0 0 1 0-1.06ZM21 12a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 21 12ZM1.5 12a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 1.5 12ZM6.22 19.187a.75.75 0 0 1 0-1.06l1.06-1.061a.75.75 0 0 1 1.06 1.06l-1.06 1.06a.75.75 0 0 1-1.06 0ZM18.127 4.813a.75.75 0 0 1 0-1.06l1.06-1.061a.75.75 0 0 1 1.06 1.06l-1.06 1.06a.75.75 0 0 1-1.06 0Z" clipRule="evenodd" />
    </svg>
);
export const SparklesIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M9.315 7.585a.75.75 0 0 1 .37.939l-.667 2.666a.75.75 0 0 1-1.416-.354l.667-2.667a.75.75 0 0 1 1.046-.584Zm4.502 4.29a.75.75 0 0 1 .37.939l-.667 2.666a.75.75 0 0 1-1.416-.354l.667-2.667a.75.75 0 0 1 1.046-.584ZM2.001 15.342a.75.75 0 0 1 .37.939l-.667 2.667a.75.75 0 0 1-1.416-.354l.667-2.667a.75.75 0 0 1 1.046-.584ZM19.64 3.04a.75.75 0 0 1 .37.939l-.667 2.666a.75.75 0 0 1-1.416-.354l.667-2.667a.75.75 0 0 1 1.046-.584ZM16.333 11.25a.75.75 0 0 1 .37.939l-.667 2.666a.75.75 0 0 1-1.416-.354l.667-2.667a.75.75 0 0 1 1.046-.584ZM12 2.25A9.75 9.75 0 0 0 2.25 12c0 5.385 4.365 9.75 9.75 9.75s9.75-4.365 9.75-9.75A9.75 9.75 0 0 0 12 2.25Z" clipRule="evenodd" />
    </svg>
);
export const ChatBubbleLeftRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M4.804 21.644A6.707 6.707 0 0 0 6 21.75a6.75 6.75 0 0 0 6.75-6.75v-2.25A6.75 6.75 0 0 0 6 6H5.25a6.75 6.75 0 0 0-6.75 6.75c0 1.62.564 3.122 1.518 4.373L0 22.5l4.804-..856ZM18.75 6.75A6.75 6.75 0 0 0 12 13.5v.75a6.75 6.75 0 0 0 1.233 3.91l-1.983.33a.75.75 0 0 0-.585 1.075l1.361 2.45a.75.75 0 0 0 1.295-.145l.591-1.063a6.72 6.72 0 0 0 4.849-3.328c.531-.96.8-2.028.8-3.116A6.75 6.75 0 0 0 18.75 6.75Z" clipRule="evenodd" />
    </svg>
);
export const MicrophoneIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M8.25 4.5a3.75 3.75 0 1 1 7.5 0v8.25a3.75 3.75 0 1 1-7.5 0V4.5Z" />
        <path d="M6 10.5a.75.75 0 0 1 .75.75v1.5a4.5 4.5 0 0 0 4.5 4.5h.75a4.5 4.5 0 0 0 4.5-4.5v-1.5a.75.75 0 0 1 1.5 0v1.5a6 6 0 0 1-6 6h-.75a6 6 0 0 1-6-6v-1.5A.75.75 0 0 1 6 10.5Z" />
    </svg>
);
export const VideoCameraIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M4.5 4.5a3 3 0 0 0-3 3v9a3 3 0 0 0 3 3h8.25a3 3 0 0 0 3-3v-9a3 3 0 0 0-3-3H4.5ZM19.5 18a1.5 1.5 0 0 0 1.5-1.5v-6a1.5 1.5 0 0 0-1.5-1.5h-.525a.75.75 0 0 0-.53.22L16.5 10.5l-1.97-1.97a.75.75 0 0 0-1.06 0l-3.03 3.03a.75.75 0 0 0 0 1.06l4.5 4.5a.75.75 0 0 0 1.06 0l1.97-1.97.97.97.53.53.22.22H19.5Z" />
    </svg>
);
export const QrCodeIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M4.5 3A1.5 1.5 0 0 0 3 4.5v2.25a1.5 1.5 0 0 0 3 0V4.5A1.5 1.5 0 0 0 4.5 3ZM1.5 4.5a3 3 0 0 1 3-3h2.25a3 3 0 0 1 3 3v2.25a3 3 0 0 1-3 3H4.5a3 3 0 0 1-3-3V4.5Zm8.25 0a1.5 1.5 0 0 0-1.5 1.5v2.25a1.5 1.5 0 0 0 3 0V6A1.5 1.5 0 0 0 9.75 4.5ZM15 3a1.5 1.5 0 0 1 1.5 1.5v2.25a1.5 1.5 0 0 1-3 0V4.5A1.5 1.5 0 0 1 15 3Zm1.5 1.5a3 3 0 0 0-3-3h2.25a3 3 0 0 0 3 3v2.25a3 3 0 0 0-3 3H15a3 3 0 0 0-3-3V6a3 3 0 0 0 3-3Zm-9.75 6.75a1.5 1.5 0 0 0-1.5 1.5v2.25a1.5 1.5 0 0 0 3 0V12a1.5 1.5 0 0 0-1.5-1.5ZM3 12a3 3 0 0 1 3-3h2.25a3 3 0 0 1 3 3v2.25a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-2.25Zm8.25 5.25a1.5 1.5 0 0 0-1.5 1.5v.75a1.5 1.5 0 0 0 3 0v-.75a1.5 1.5 0 0 0-1.5-1.5Z" clipRule="evenodd" />
        <path d="M12.75 18a1.5 1.5 0 0 1-3 0v-.75a1.5 1.5 0 0 1 3 0v.75Zm3.75-1.5a1.5 1.5 0 0 0-1.5 1.5v.75a1.5 1.5 0 0 0 3 0v-.75a1.5 1.5 0 0 0-1.5-1.5Zm4.5 1.5a1.5 1.5 0 0 1-3 0v-.75a1.5 1.5 0 0 1 3 0v.75Z" />
    </svg>
);
export const CarIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V3.375c0-1.036-.84-1.875-1.875-1.875H5.625ZM12 18a.75.75 0 0 0 .75.75h3a.75.75 0 0 0 0-1.5h-3A.75.75 0 0 0 12 18ZM12 15a.75.75 0 0 0 .75.75h3a.75.75 0 0 0 0-1.5h-3A.75.75 0 0 0 12 15ZM12 12a.75.75 0 0 0 .75.75h3a.75.75 0 0 0 0-1.5h-3A.75.75 0 0 0 12 12ZM8.25 18a.75.75 0 0 1 .75-.75h.01a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM8.25 15a.75.75 0 0 1 .75-.75h.01a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM8.25 12a.75.75 0 0 1 .75-.75h.01a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM8.25 9a.75.75 0 0 1 .75-.75h5.25a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM8.25 6a.75.75 0 0 1 .75-.75h5.25a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Z" />
    </svg>
);
export const HomeIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M11.47 3.841a.75.75 0 0 1 1.06 0l8.69 8.69a.75.75 0 1 0 1.06-1.061l-8.689-8.69a2.25 2.25 0 0 0-3.182 0l-8.69 8.69a.75.75 0 1 0 1.061 1.06l8.69-8.69Z" />
        <path d="M12 5.432 4.136 13.3a.75.75 0 0 1-1.06-1.06l7.933-7.933a.75.75 0 0 1 1.06 0l7.933 7.933a.75.75 0 0 1-1.06 1.06L12 5.432Z" />
    </svg>
);
export const AcIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-2.625 6a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5h-3.75a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5h-3.75a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5h-3.75a.75.75 0 0 1-.75-.75Z" />
    </svg>
);
export const PlumbingIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M14.25 4.5A2.25 2.25 0 0 0 12 6.75v10.5a2.25 2.25 0 0 0 4.5 0V6.75A2.25 2.25 0 0 0 14.25 4.5Z" />
        <path d="M8.25 4.5A2.25 2.25 0 0 0 6 6.75v3A2.25 2.25 0 0 0 8.25 12h1.5a.75.75 0 0 0 0-1.5h-1.5a.75.75 0 0 1-.75-.75v-3c0-.414.336-.75.75-.75h7.5c.414 0 .75.336.75.75v10.5a.75.75 0 0 1-.75-.75h-1.5a.75.75 0 0 0 0 1.5h1.5A2.25 2.25 0 0 0 18 17.25V6.75A2.25 2.25 0 0 0 15.75 4.5h-7.5Z" />
    </svg>
);
export const OilDropIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M12 2.25c-5.336 0-9.75 4.336-9.75 9.665 0 4.252 2.76 7.86 6.5 9.176.842.302 1.748.459 2.68.459h.14c.932 0 1.838-.157 2.68-.459 3.74-1.316 6.5-4.924 6.5-9.176C21.75 6.586 17.336 2.25 12 2.25Z" />
    </svg>
);
export const BoltIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M14.615 1.595a.75.75 0 0 1 .359.852L12.982 9.75h7.268a.75.75 0 0 1 .548 1.262l-10.5 11.25a.75.75 0 0 1-1.272-.71l2.018-9.75H2.75a.75.75 0 0 1-.548-1.262l10.5-11.25a.75.75 0 0 1 .913-.143Z" clipRule="evenodd" />
    </svg>
);
export const ListBulletIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M3 6.75A.75.75 0 0 1 3.75 6h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 6.75ZM3 12a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 12Zm0 5.25a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75a.75.75 0 0 1-.75-.75Z" clipRule="evenodd" />
    </svg>
);
export const LightBulbIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12 2.25a.75.75 0 0 1 .75.75v.511c1.18.293 2.25.938 3.067 1.838l.42-.42a.75.75 0 0 1 1.06 1.06l-.42.42a4.5 4.5 0 0 1 1.838 3.067h.511a.75.75 0 0 1 0 1.5h-.511a4.5 4.5 0 0 1-1.838 3.067l.42.42a.75.75 0 0 1-1.06 1.06l-.42-.42a4.5 4.5 0 0 1-3.067 1.838v.511a.75.75 0 0 1-1.5 0v-.511a4.5 4.5 0 0 1-3.067-1.838l-.42.42a.75.75 0 0 1-1.06-1.06l.42-.42a4.5 4.5 0 0 1-1.838-3.067H3a.75.75 0 0 1 0-1.5h.511a4.5 4.5 0 0 1 1.838-3.067l-.42-.42a.75.75 0 0 1 1.06-1.06l.42.42A4.5 4.5 0 0 1 9.75 3.511V3a.75.75 0 0 1 .75-.75Zm-3.121 9.47a.75.75 0 0 0-1.06 1.06l.47.47-1.106 1.105a.75.75 0 0 0 1.06 1.06L9.47 14.12l.47.47a.75.75 0 0 0 1.06-1.06l-2.62-2.62Z" />
    </svg>
);