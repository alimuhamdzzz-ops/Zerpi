import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Type } from '@google/genai';

import {
  UserRole,
  CustomerPage,
  TechnicianPage,
  PartnerPage,
  DeliveryPage,
  ServiceJob,
  Technician,
  SparePart,
  PartOrder,
  AiChatMessage,
  TechChatMessage,
  InspectionReport,
  DeliveryOption,
  DeliveryPerson,
  CustomerTechMessage
} from './types';

import {
  MOCK_TECHNICIANS,
  MOCK_DELIVERY_PEOPLE,
  MOCK_SPARE_PARTS,
  MOCK_AI_CONVERSATION,
  MOCK_TECH_CHAT,
  MOCK_CUSTOMER_TECH_CHAT,
  UserIcon,
  WrenchScrewdriverIcon,
  BuildingStorefrontIcon,
  TruckIcon,
  StarIcon,
  ArrowLeftIcon,
  MagnifyingGlassIcon,
  PaperAirplaneIcon,
  CameraIcon,
  PlusIcon,
  CheckCircleIcon,
  ClockIcon,
  CogIcon,
  SparklesIcon,
  ChatBubbleLeftRightIcon,
  MicrophoneIcon,
  VideoCameraIcon,
  QrCodeIcon,
  CarIcon,
  HomeIcon,
  GEMINI_MODEL,
  AcIcon,
  PlumbingIcon,
  OilDropIcon,
  BoltIcon,
  ListBulletIcon,
  LightBulbIcon
} from './constants';

// --- HELPER FUNCTIONS ---
const generateVerificationCode = () => Math.random().toString(36).substring(2, 8).toUpperCase();

// --- NEW 3D ZERPI LOGO COMPONENT ---
const ZerpiLogo3D = (props: React.SVGProps<SVGSVGElement>) => (
    <svg viewBox="0 0 320 100" xmlns="http://www.w3.org/2000/svg" {...props}>
        <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style={{stopColor: '#FDBA74', stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: '#F97316', stopOpacity: 1}} />
            </linearGradient>
            <filter id="dropShadow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
                <feOffset dx="2" dy="4" result="offsetblur"/>
                <feFlood floodColor="#000000" floodOpacity="0.5"/>
                <feComposite in2="offsetblur" operator="in"/>
                <feMerge>
                    <feMergeNode/>
                    <feMergeNode in="SourceGraphic"/>
                </feMerge>
            </filter>
        </defs>
        <g filter="url(#dropShadow)">
            <text x="10" y="75" fontFamily="'Segoe UI', 'Helvetica Neue', sans-serif" fontSize="60" fontWeight="bold" fill="white">
                zer
                <tspan fill="url(#grad1)">P</tspan>
                i
            </text>
        </g>
    </svg>
);

const SwitchRoleButton = ({ onSwitch }: { onSwitch: () => void }) => (
    <button onClick={onSwitch} className="bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-full hover:bg-orange-500 transition-colors shadow-lg">
        Switch Role
    </button>
);

const LiveTrackingMap: React.FC<{ durationMinutes: number, vehicleType: 'van' | 'bike' | 'tech' }> = ({ durationMinutes, vehicleType }) => {
    const totalDuration = durationMinutes * 60 * 1000;
    const [progress, setProgress] = useState(0);
    const [eta, setEta] = useState(durationMinutes);

    useEffect(() => {
        const startTime = Date.now();
        const interval = setInterval(() => {
            const elapsedTime = Date.now() - startTime;
            const currentProgress = Math.min(elapsedTime / totalDuration, 1);
            setProgress(currentProgress);

            const remainingMinutes = Math.ceil((totalDuration - elapsedTime) / (60 * 1000));
            setEta(Math.max(0, remainingMinutes));

            if (currentProgress >= 1) {
                clearInterval(interval);
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [totalDuration]);
    
    const vehicleIcon = {
        van: <TruckIcon className="w-8 h-8 text-white transform -scale-x-100" />,
        bike: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-white"><path d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM9.53 15.145a.75.75 0 0 1-1.06 0 3 3 0 0 1 0-4.243.75.75 0 0 1 1.06 1.061 1.5 1.5 0 0 0 0 2.121.75.75 0 0 1 0 1.06Zm4.5-4.242a.75.75 0 0 1 1.06-1.061 3 3 0 0 1 0 4.243.75.75 0 0 1-1.06-1.06 1.5 1.5 0 0 0 0-2.122Z" /></svg>,
        tech: <WrenchScrewdriverIcon className="w-8 h-8 text-white" />
    }[vehicleType];


    return (
        <div className="bg-slate-700 p-4 rounded-xl text-center">
            <h3 className="text-lg font-bold mb-2">Live Tracking</h3>
            <p className="text-3xl font-bold text-orange-400 mb-4">ETA: {eta} mins</p>
            <div className="h-48 bg-slate-800 rounded-lg flex items-center justify-center text-slate-500 overflow-hidden relative">
                <div className="w-full h-1 bg-slate-600 absolute top-1/2 -translate-y-1/2">
                    <div className="h-1 bg-orange-500" style={{ width: `${progress * 100}%` }}></div>
                </div>
                <div className="absolute top-1/2 -translate-y-1/2 transition-all duration-1000 ease-linear" style={{ left: `calc(${progress * 100}% - 16px)` }}>
                   <div className="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center ring-4 ring-slate-800">{vehicleIcon}</div>
                </div>
                 <div className="absolute top-1/2 left-2 -translate-y-1/2 text-green-400"><HomeIcon className="w-8 h-8"/></div>
                 <div className="absolute top-1/2 right-2 -translate-y-1/2 text-red-400"><CogIcon className="w-8 h-8"/></div>
            </div>
        </div>
    );
};


// --- CUSTOMER APP ---
interface CustomerAppProps {
    user: { name: string };
    jobs: ServiceJob[];
    technicians: Technician[];
    orders: PartOrder[];
    deliveryPeople: DeliveryPerson[];
    customerTechMessages: CustomerTechMessage[];
    onSwitchRole: () => void;
    handleCreateJob: (serviceType: string, problemSummary: string) => void;
    handleSelectTechnician: (jobId: string, technician: Technician) => void;
    handleUpdateJobStatus: (jobId: string, status: ServiceJob['status']) => void;
    handleJobReview: (jobId: string, rating: number, comment: string) => void;
    handleCancelJob: (jobId: string) => void;
    handleApproveJobWithDelivery: (jobId: string, deliveryOption: DeliveryOption) => void;
    handleSendMessageToTech: (message: CustomerTechMessage) => void;
}
const CustomerApp: React.FC<CustomerAppProps> = ({ user, jobs, technicians, orders, deliveryPeople, customerTechMessages, onSwitchRole, handleCreateJob, handleSelectTechnician, handleUpdateJobStatus, handleJobReview, handleCancelJob, handleApproveJobWithDelivery, handleSendMessageToTech }) => {
    const [page, setPage] = useState<CustomerPage>('SPLASH');

    const activeJob = jobs.find(j => !['Completed', 'Declined', 'Paid'].includes(j.status));


    useEffect(() => {
        if (page === 'SPLASH') {
            const timer = setTimeout(() => setPage('HOME'), 2500);
            return () => clearTimeout(timer);
        }
    }, [page]);

    const renderContent = () => {
        if (page === 'SPLASH') return <CustomerSplashPage />;
        
        if (activeJob) {
            if (activeJob.status === 'Requested') {
                return <CustomerTechnicianSelectionPage job={activeJob} onSelect={(tech) => handleSelectTechnician(activeJob.id, tech)} onBack={() => handleCancelJob(activeJob.id)} technicians={technicians} />;
            }
            const selectedTechnician = technicians.find(t => t.id === activeJob.technicianId);
            const relatedOrders = orders.filter(o => activeJob.partOrderIds.includes(o.id));
            if (selectedTechnician) {
                return <CustomerJobTrackingPage job={activeJob} technician={selectedTechnician} onUpdateStatus={handleUpdateJobStatus} relatedOrders={relatedOrders} deliveryPeople={deliveryPeople} onJobReview={handleJobReview} onApproveWithDelivery={handleApproveJobWithDelivery} messages={customerTechMessages} onSendMessage={handleSendMessageToTech} onSwitchRole={onSwitchRole} />
            }
        }
        
        return (
             <div className="w-full h-full flex flex-col bg-slate-900">
                <main className="flex-grow overflow-y-auto pb-20">
                   {page === 'HOME' && <CustomerHomePage user={user} onServiceSelect={(serviceType) => handleCreateJob(serviceType, `Standard request for ${serviceType}.`)} onSwitchRole={onSwitchRole} />}
                   {page === 'AI_ASSIST' && <CustomerAiAssistPage onCreateJob={handleCreateJob} onSwitchRole={onSwitchRole} />}
                   {page === 'HISTORY' && <CustomerHistoryPage jobs={jobs.filter(j => j.status === 'Completed' || j.status === 'Paid')} technicians={technicians} />}
                   {page === 'PROFILE' && <CustomerProfilePage user={user} />}
                </main>
                <CustomerBottomNav currentPage={page} setPage={setPage} />
             </div>
        )
    };
    return <div className="w-full h-full">{renderContent()}</div>;
};

const CustomerSplashPage: React.FC = () => (
    <div className="w-full h-full flex flex-col justify-center items-center bg-gradient-to-br from-slate-900 to-gray-900 animate-fade-in">
        <div className="animate-pulse">
          <ZerpiLogo3D className="w-64 h-auto" />
        </div>
    </div>
);

const ShortcutButton: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void; }> = ({ icon, label, onClick }) => (
    <button onClick={onClick} className="flex flex-col items-center justify-center p-4 bg-slate-800 rounded-2xl text-center border border-slate-700 cursor-pointer hover:bg-orange-600/20 hover:border-orange-500 transition-all duration-300 transform hover:-translate-y-1">
        <div className="text-orange-400">{icon}</div>
        <span className="text-sm font-semibold mt-2 text-slate-200">{label}</span>
    </button>
);

const CustomerHomePage: React.FC<{ user: { name: string }, onServiceSelect: (serviceType: string) => void; onSwitchRole: () => void; }> = ({ user, onServiceSelect, onSwitchRole }) => {
    return (
        <div className="w-full h-full flex flex-col bg-slate-900 text-white overflow-y-auto p-6">
            <header className="flex items-start justify-between mb-8">
                 <div>
                    <h1 className="text-3xl font-bold text-orange-500">Zerpi</h1>
                    <p className="text-sm text-slate-400">Welcome, {user.name}</p>
                 </div>
                 <SwitchRoleButton onSwitch={onSwitchRole} />
            </header>
            <div className="text-left mb-10">
                <h2 className="text-4xl font-extrabold mb-2">Instant Help,</h2>
                <p className="text-3xl text-slate-400">On-Demand</p>
            </div>
            <div>
                <h3 className="text-xl font-semibold mb-4 text-slate-300">Quick Services</h3>
                <div className="mb-6">
                    <p className="font-bold mb-3 text-orange-400">Home Services</p>
                    <div className="grid grid-cols-3 gap-4">
                        <ShortcutButton icon={<AcIcon className="w-8 h-8"/>} label="AC Repair" onClick={() => onServiceSelect("AC Repair")} />
                        <ShortcutButton icon={<PlumbingIcon className="w-8 h-8"/>} label="Plumbing" onClick={() => onServiceSelect("Plumbing")} />
                        <ShortcutButton icon={<BoltIcon className="w-8 h-8"/>} label="Electrical" onClick={() => onServiceSelect("Electrical")} />
                    </div>
                </div>
                 <div>
                    <p className="font-bold mb-3 text-orange-400">Vehicle Services</p>
                    <div className="grid grid-cols-3 gap-4">
                         <ShortcutButton icon={<OilDropIcon className="w-8 h-8"/>} label="Oil Change" onClick={() => onServiceSelect("Oil Change")} />
                         <ShortcutButton icon={<CogIcon className="w-8 h-8"/>} label="Mechanical" onClick={() => onServiceSelect("Mechanical Repair")} />
                         <ShortcutButton icon={<CarIcon className="w-8 h-8"/>} label="Car Wash" onClick={() => onServiceSelect("Car Wash")} />
                    </div>
                </div>
            </div>
        </div>
    );
};

const CustomerAiAssistPage: React.FC<{ onCreateJob: (serviceType: string, problemSummary: string) => void; onSwitchRole: () => void; }> = ({ onCreateJob, onSwitchRole }) => {
    const [messages, setMessages] = useState<AiChatMessage[]>(MOCK_AI_CONVERSATION);
    const [input, setInput] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const chatEndRef = useRef<HTMLDivElement>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleOpenCamera = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
            setIsCameraOpen(true);
        } catch (err) {
            console.error("Error accessing camera:", err);
            alert("Could not access camera. Please check permissions.");
        }
    };

    const handleTakePicture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            context?.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.8);

            const stream = video.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            video.srcObject = null;
            setIsCameraOpen(false);

            handleSendMessage(dataUrl, true);
        }
    };

    const handleSendMessage = async (content: string, isImage: boolean = false) => {
        if (!content.trim()) return;
        
        const userMessage: AiChatMessage = {
            sender: 'user',
            text: isImage ? 'Here is a photo of the issue.' : content,
            image: isImage ? content : undefined,
        };
        setMessages(prev => [...prev, userMessage]);
        setInput("");
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const serviceSchema = {
                type: Type.OBJECT,
                properties: {
                    problemSummary: { type: Type.STRING, description: 'A concise, friendly summary of the customer\'s issue in 1-2 sentences.' },
                    serviceRequired: { type: Type.STRING, description: 'The specific service category needed, choose one: "AC Repair", "Plumbing", "Electrical", "Oil Change", "Mechanical Repair", "Car Wash", or "General Inquiry".' },
                    urgency: { type: Type.STRING, description: 'The urgency level, choose one: "Low", "Medium", "High", or "Emergency".' },
                },
                required: ['problemSummary', 'serviceRequired', 'urgency']
            };
            
            const parts: any[] = [];
            let promptText = '';

            if (isImage) {
                const base64Data = content.split(',')[1];
                parts.push({
                    inlineData: {
                        mimeType: 'image/jpeg',
                        data: base64Data,
                    },
                });
                promptText = "A customer has sent an image of a problem they are facing. Analyze the image to identify the issue and provide a structured JSON summary of the problem, the likely service required, and the urgency. If you cannot determine the issue from the image, ask for a text description.";
            } else {
                promptText = `A customer needs help. Analyze their request and provide a structured JSON summary. Request: "${content}"`;
            }
            parts.push({ text: promptText });


            const response = await ai.models.generateContent({
                model: GEMINI_MODEL,
                contents: { parts: parts },
                config: {
                    responseMimeType: "application/json",
                    responseSchema: serviceSchema,
                },
            });

            const jsonString = response.text.trim();
            const parsedData = JSON.parse(jsonString);
            
            const aiResponse: AiChatMessage = {
                sender: 'ai',
                text: "I've analyzed the issue. Here's a summary. Does this look correct?",
                data: parsedData,
            };
            setMessages(prev => [...prev, aiResponse]);

        } catch (error) {
            console.error("AI Diagnosis Error:", error);
            const errorResponse: AiChatMessage = { sender: 'ai', text: "I had trouble analyzing that. Could you please describe the problem differently?" };
            setMessages(prev => [...prev, errorResponse]);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="flex flex-col h-full bg-slate-900 text-white">
            {isCameraOpen && (
                <div className="absolute inset-0 bg-black z-30 flex flex-col items-center justify-center">
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover"></video>
                    <canvas ref={canvasRef} className="hidden"></canvas>
                     <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/50 flex justify-center items-center">
                        <button onClick={() => {
                            const stream = videoRef.current?.srcObject as MediaStream;
                            stream?.getTracks().forEach(track => track.stop());
                            if(videoRef.current) videoRef.current.srcObject = null;
                            setIsCameraOpen(false);
                        }} className="absolute left-4 p-3 bg-gray-600/80 rounded-full text-white">
                            Cancel
                        </button>
                        <button onClick={handleTakePicture} className="p-4 bg-white rounded-full ring-4 ring-white/30">
                           <div className="w-8 h-8 bg-white rounded-full border-4 border-black"></div>
                        </button>
                    </div>
                </div>
            )}
            <header className="p-4 flex-shrink-0 z-10 flex items-center justify-between bg-slate-900 border-b border-slate-700 shadow-md">
                 <h2 className="text-xl font-bold text-white flex items-center gap-2"><SparklesIcon className="w-6 h-6 text-orange-400" /> AI Assistant</h2>
                 <SwitchRoleButton onSwitch={onSwitchRole} />
            </header>
            <div className="flex-grow p-4 space-y-4 overflow-y-auto">
                {messages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`p-3 rounded-xl max-w-[85%] ${msg.sender === 'user' ? 'bg-orange-600' : 'bg-slate-700'}`}>
                            {msg.image && <img src={msg.image} alt="User upload" className="rounded-lg mb-2 max-h-60" />}
                            <p>{msg.text}</p>
                            {msg.sender === 'ai' && msg.data && (
                                <div className="mt-3 pt-3 border-t border-slate-600 bg-slate-800 p-3 rounded-lg">
                                    <p><strong>Summary:</strong> {msg.data.problemSummary}</p>
                                    <p><strong>Service:</strong> {msg.data.serviceRequired}</p>
                                    <p><strong>Urgency:</strong> {msg.data.urgency}</p>
                                    <button onClick={() => onCreateJob(msg.data.serviceRequired, msg.data.problemSummary)} className="w-full mt-3 bg-green-600 text-white font-bold p-2 rounded-lg hover:bg-green-500 transition">Confirm & Find Technician</button>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
                {isLoading && <div className="flex justify-start"><div className="p-3 rounded-lg bg-slate-700 animate-pulse">Thinking...</div></div>}
                 <div ref={chatEndRef} />
            </div>
            <div className="p-4 bg-slate-800 border-t border-slate-700">
                <div className="flex items-center gap-2 bg-slate-700 rounded-xl p-2">
                    <button onClick={handleOpenCamera} className="p-2 text-slate-400 hover:text-orange-400 transition-colors" aria-label="Open camera">
                        <CameraIcon className="w-6 h-6" />
                    </button>
                     <button onClick={() => alert("Video input coming soon!")} className="p-2 text-slate-400 hover:text-orange-400 transition-colors" aria-label="Upload video">
                        <VideoCameraIcon className="w-6 h-6" />
                    </button>
                    <button onClick={() => alert("Voice input coming soon!")} className="p-2 text-slate-400 hover:text-orange-400 transition-colors" aria-label="Record voice note">
                        <MicrophoneIcon className="w-6 h-6" />
                    </button>
                    <input 
                        type="text" 
                        value={input} 
                        onChange={e => setInput(e.target.value)} 
                        onKeyPress={e => e.key === 'Enter' && handleSendMessage(input, false)} 
                        placeholder="Describe your issue..." 
                        className="w-full bg-transparent text-white placeholder-slate-400 focus:ring-0 outline-none px-2"
                    />
                    <button 
                        onClick={() => handleSendMessage(input, false)} 
                        disabled={!input.trim() || isLoading} 
                        className="p-3 bg-orange-600 rounded-full text-white disabled:bg-slate-600">
                        <PaperAirplaneIcon className="w-6 h-6"/>
                    </button>
                </div>
            </div>
        </div>
    );
};

const CustomerTechnicianSelectionPage: React.FC<{ job: ServiceJob, onSelect: (technician: Technician) => void; onBack: () => void; technicians: Technician[] }> = ({ job, onSelect, onBack, technicians }) => {
    const [selectedTech, setSelectedTech] = useState<Technician | null>(null);
    const [aiRecommendedTechId, setAiRecommendedTechId] = useState<string | null>(null);
    const [sortBy, setSortBy] = useState<'recommend' | 'rating' | 'distance'>('recommend');

    const getSortedTechnicians = useCallback(() => {
        const specialists = technicians.filter(t => t.specialization === job.serviceType || (job.serviceType.includes('Oil') && t.specialization === 'Vehicle Maintenance'));
        const others = technicians.filter(t => !specialists.includes(t));
        let sorted = [...specialists, ...others];

        if (sortBy === 'rating') {
            sorted.sort((a, b) => b.rating - a.rating);
        } else if (sortBy === 'distance') {
            sorted.sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));
        }
        return sorted;
    }, [technicians, job.serviceType, sortBy]);

    const [availableTechnicians, setAvailableTechnicians] = useState(getSortedTechnicians);

    useEffect(() => {
        setAvailableTechnicians(getSortedTechnicians());
    }, [sortBy, getSortedTechnicians]);

    const handleAiSuggestion = () => {
        setSortBy('recommend');
        const specialists = technicians.filter(t => t.specialization === job.serviceType || (job.serviceType.includes('Oil') && t.specialization === 'Vehicle Maintenance'));
        if (specialists.length > 0) {
            const recommended = [...specialists].sort((a,b) => b.rating - a.rating)[0];
            setAiRecommendedTechId(recommended.id);
            setSelectedTech(recommended);
        } else if (availableTechnicians.length > 0) {
            const recommended = [...availableTechnicians].sort((a,b) => b.rating - a.rating)[0];
            setAiRecommendedTechId(recommended.id);
            setSelectedTech(recommended);
        }
    };
    
    return (
        <div className="w-full h-full flex flex-col bg-slate-900">
            <header className="p-4 flex-shrink-0 z-10 flex items-center bg-slate-900 border-b border-slate-700 shadow-md">
                <button onClick={onBack} className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition">
                    <ArrowLeftIcon className="w-6 h-6 text-white"/>
                </button>
                <h2 className="text-xl font-bold text-white ml-4">Select a Technician</h2>
            </header>
            <div className="p-4 flex-shrink-0">
                 <p className="text-slate-400 mb-2">Showing specialists for "{job.serviceType}"</p>
                 <div className="flex gap-2 mb-2">
                     <button onClick={() => setSortBy('rating')} className={`flex-1 p-2 rounded-lg text-sm font-semibold ${sortBy === 'rating' ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-300'}`}>Sort by Rating</button>
                     <button onClick={() => setSortBy('distance')} className={`flex-1 p-2 rounded-lg text-sm font-semibold ${sortBy === 'distance' ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-300'}`}>Sort by Distance</button>
                     <button onClick={handleAiSuggestion} className={`flex items-center justify-center gap-1 p-2 rounded-lg text-sm font-semibold ${sortBy === 'recommend' ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-300'}`}><LightBulbIcon className="w-4 h-4" /> Suggest</button>
                 </div>
            </div>
            <div className="flex-grow p-4 pt-0 space-y-3 overflow-y-auto">
                {availableTechnicians.length > 0 ? availableTechnicians.map(tech => (
                    <div key={tech.id} onClick={() => setSelectedTech(tech)} className={`relative flex items-start p-4 bg-slate-800 rounded-xl cursor-pointer border-2 transition-all duration-200 ${selectedTech?.id === tech.id ? 'border-orange-500 ring-2 ring-orange-500/50' : 'border-slate-700 hover:border-orange-500/50'}`}>
                        {aiRecommendedTechId === tech.id && <div className="absolute -top-2 -left-2 text-xs bg-orange-500 text-white font-bold px-2 py-0.5 rounded-full z-10 flex items-center gap-1"><StarIcon className="w-3 h-3"/> Recommended</div>}
                        <img src={tech.photoUrl} alt={tech.name} className="w-16 h-16 rounded-full mr-4 border-2 border-orange-500"/>
                        <div className="flex-grow">
                            <h3 className="text-lg font-semibold text-white">{tech.name}</h3>
                            <p className="text-slate-400 text-sm">{tech.specialization}</p>
                            <div className="flex items-center text-xs text-slate-400 mt-1 space-x-2">
                                {tech.skills.slice(0, 2).map(skill => <span key={skill} className="bg-slate-700 px-2 py-0.5 rounded-full">{skill}</span>)}
                            </div>
                        </div>
                        <div className="text-right flex-shrink-0 ml-2">
                            <div className="flex items-center justify-end text-yellow-400 mb-1"><StarIcon className="w-5 h-5 mr-1"/><span className="font-bold">{tech.rating}</span></div>
                            <p className="text-slate-300 text-sm">{tech.distance}</p>
                            <p className="text-orange-400 text-sm font-bold">ETA: {tech.eta}</p>
                        </div>
                        {selectedTech?.id === tech.id && <div className="absolute top-2 right-2 text-green-400 bg-slate-900 rounded-full"><CheckCircleIcon className="w-6 h-6"/></div>}
                    </div>
                )) : <p className="text-slate-400 text-center py-8">No technicians available for this service.</p>}
            </div>
            <div className="p-4 bg-slate-900 border-t border-slate-700 flex-shrink-0">
                <button onClick={() => selectedTech && onSelect(selectedTech)} disabled={!selectedTech} className="w-full bg-orange-600 text-white font-bold py-4 rounded-xl hover:bg-orange-500 transition disabled:bg-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed">
                    Confirm Technician
                </button>
            </div>
        </div>
    );
};

const JobTimeline: React.FC<{ job: ServiceJob }> = ({ job }) => {
    const getStatusMap = (status: ServiceJob['status']) => [
        { name: 'Job Requested', completed: true },
        { name: 'Technician Assigned', completed: !!job.technicianId },
        { name: 'Technician En Route', completed: !['Requested', 'Assigned'].includes(status) },
        { name: 'Technician Inspection', completed: !['Requested', 'Assigned', 'En Route'].includes(status) },
        { name: 'Customer Approval', completed: !['Requested', 'Assigned', 'En Route', 'Inspection', 'Awaiting Approval', 'Declined'].includes(status) },
        { name: 'Parts Ordered', completed: ['In Progress', 'Completed', 'Awaiting Payment', 'Paid'].includes(status) || status === 'Parts Ordered' },
        { name: 'Work in Progress', completed: ['In Progress', 'Completed', 'Awaiting Payment', 'Paid'].includes(status) },
        { name: 'Payment Due', completed: ['Awaiting Payment', 'Paid'].includes(status) },
        { name: 'Completed & Paid', completed: status === 'Paid' },
    ];

    const timeline = getStatusMap(job.status);
    
    return (
      <div className="mt-8 bg-slate-800 p-4 rounded-lg">
        <h3 className="text-lg font-bold mb-4 text-slate-300">Job Progress</h3>
        <ol className="relative border-l border-slate-700 ml-4">
            {timeline.map((event, index) => (
                 <li key={index} className="mb-6 ml-8">
                    <span className={`absolute flex items-center justify-center w-8 h-8 rounded-full -left-4 ring-4 ring-slate-800 ${event.completed ? 'bg-green-500' : 'bg-slate-700'}`}>
                         {event.completed ? <CheckCircleIcon className="w-5 h-5 text-white" /> : <ClockIcon className="w-5 h-5 text-slate-400" />}
                    </span>
                    <h4 className={`font-semibold ${event.completed ? 'text-white' : 'text-slate-500'}`}>{event.name}</h4>
                 </li>
            ))}
        </ol>
      </div>
    );
};

const StarRatingInput: React.FC<{ rating: number; setRating: (rating: number) => void }> = ({ rating, setRating }) => (
    <div className="flex justify-center my-4">
        {[1, 2, 3, 4, 5].map((star) => (
            <StarIcon
                key={star}
                className={`w-10 h-10 cursor-pointer transition-colors ${rating >= star ? 'text-yellow-400' : 'text-slate-600 hover:text-yellow-500'}`}
                onClick={() => setRating(star)}
            />
        ))}
    </div>
);

const CustomerTechnicianChatModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    messages: CustomerTechMessage[];
    onSendMessage: (message: CustomerTechMessage) => void;
    technicianName: string;
}> = ({ isOpen, onClose, messages, onSendMessage, technicianName }) => {
    const [input, setInput] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages, isOpen]);

    if (!isOpen) return null;

    const handleSend = () => {
        if (input.trim()) {
            onSendMessage({
                sender: 'customer',
                text: input,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            });
            setInput('');
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex flex-col animate-fade-in">
            <header className="p-4 flex-shrink-0 flex items-center bg-slate-800 border-b border-slate-700">
                <button onClick={onClose} className="p-2 text-white"><ArrowLeftIcon className="w-6 h-6" /></button>
                <h2 className="text-xl font-bold text-white ml-4">Chat with {technicianName}</h2>
            </header>
            <div className="flex-grow p-4 space-y-4 overflow-y-auto">
                {messages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.sender === 'customer' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`p-3 rounded-xl max-w-[85%] ${msg.sender === 'customer' ? 'bg-orange-600 text-white' : 'bg-slate-700 text-white'}`}>
                            <p>{msg.text}</p>
                            <p className="text-xs text-right mt-1 opacity-70">{msg.timestamp}</p>
                        </div>
                    </div>
                ))}
                <div ref={chatEndRef}></div>
            </div>
            <div className="p-4 bg-slate-800 border-t border-slate-700">
                <div className="flex items-center gap-2 bg-slate-700 rounded-xl p-2">
                    <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSend()} placeholder="Type a message..." className="w-full bg-transparent text-white placeholder-slate-400 focus:ring-0 outline-none px-2" />
                    <button onClick={handleSend} disabled={!input.trim()} className="p-3 bg-orange-600 rounded-full text-white disabled:bg-slate-600"><PaperAirplaneIcon className="w-6 h-6" /></button>
                </div>
            </div>
        </div>
    );
};


const CustomerJobTrackingPage: React.FC<{ job: ServiceJob; technician: Technician; onUpdateStatus: (jobId: string, status: ServiceJob['status']) => void; relatedOrders: PartOrder[], deliveryPeople: DeliveryPerson[], onJobReview: (jobId: string, rating: number, comment: string) => void; onApproveWithDelivery: (jobId: string, deliveryOption: DeliveryOption) => void; messages: CustomerTechMessage[], onSendMessage: (message: CustomerTechMessage) => void; onSwitchRole: () => void; }> = ({ job, technician, onUpdateStatus, relatedOrders, deliveryPeople, onJobReview, onApproveWithDelivery, messages, onSendMessage, onSwitchRole }) => {
    const report = job.inspectionReport;
    const [rating, setRating] = useState(job.review?.rating || 0);
    const [comment, setComment] = useState(job.review?.comment || '');
    const [reviewSubmitted, setReviewSubmitted] = useState(!!job.review);
    const [selectedDelivery, setSelectedDelivery] = useState<DeliveryOption | null>(null);
    const [showChat, setShowChat] = useState(false);

    useEffect(() => {
        if (report?.deliveryOptions && report.deliveryOptions.length > 0) {
            setSelectedDelivery(report.deliveryOptions[0]);
        }
    }, [report]);

    const handleReviewSubmit = () => {
        if (rating > 0) {
            onJobReview(job.id, rating, comment);
            setReviewSubmitted(true);
        } else {
            alert("Please provide a rating.");
        }
    };
    
    const handleApproval = () => {
        if (report?.requiredParts.length && report.requiredParts.some(p => p.part.availability.some(a => a.stock > 0)) && !selectedDelivery) {
            alert("Please select a delivery option for the parts.");
            return;
        }
        if (selectedDelivery) {
            onApproveWithDelivery(job.id, selectedDelivery);
        } else {
             onUpdateStatus(job.id, 'Approved');
        }
    };

    return (
        <div className="w-full h-full flex flex-col bg-slate-900 text-white">
            <header className="p-4 flex-shrink-0 z-10 flex items-center justify-between bg-slate-900 border-b border-slate-700 shadow-md">
                 <h2 className="text-xl font-bold text-white flex items-center gap-2"><ListBulletIcon className="w-6 h-6 text-orange-400" /> Job Status</h2>
                 <SwitchRoleButton onSwitch={onSwitchRole} />
            </header>
            
            <div className="flex-grow p-4 overflow-y-auto">
                <div className="bg-slate-800 p-4 rounded-xl mb-4 flex items-center justify-between">
                    <div className="flex items-center">
                        <img src={technician.photoUrl} alt={technician.name} className="w-14 h-14 rounded-full mr-4 border-2 border-orange-500"/>
                        <div>
                            <h3 className="text-lg font-bold">{technician.name}</h3>
                            <p className="text-sm text-slate-400">{technician.specialization}</p>
                            <div className="flex items-center text-yellow-400 text-sm"><StarIcon className="w-4 h-4 mr-1"/> {technician.rating}</div>
                        </div>
                    </div>
                    <button onClick={() => setShowChat(true)} className="p-3 bg-orange-600 rounded-full hover:bg-orange-500">
                        <ChatBubbleLeftRightIcon className="w-6 h-6 text-white" />
                    </button>
                </div>

                {job.status === 'En Route' && (
                    <LiveTrackingMap durationMinutes={parseInt(technician.eta || '10')} vehicleType="tech" />
                )}
                
                {job.status === 'Inspection' && (
                     <div className="bg-slate-800 p-4 rounded-xl text-center animate-pulse">
                        <h3 className="text-lg font-bold mb-2">Inspection in Progress</h3>
                        <p className="text-slate-400">Your technician is diagnosing the issue. You'll receive a report shortly.</p>
                    </div>
                )}
                
                {job.status === 'Awaiting Approval' && report && (
                     <div className="bg-slate-800 p-4 rounded-xl">
                        <h3 className="text-xl font-bold mb-3 text-orange-400">Inspection Report</h3>
                        <div className="space-y-2 text-slate-300 mb-4">
                            <p><strong>Fault Summary:</strong> {report.faultSummary}</p>
                            <p><strong>Est. Fix Time:</strong> {report.estimatedFixTime}</p>
                        </div>
                        
                        {report.requiredParts.length > 0 && (
                            <>
                                <h4 className="font-bold mb-2 text-slate-200">Required Parts:</h4>
                                <ul className="space-y-2 mb-4">
                                    {report.requiredParts.map(({part, quantity}) => (
                                        <li key={part.id} className="bg-slate-700 p-3 rounded-lg flex items-center">
                                            <img src={part.imageUrl} alt={part.name} className="w-12 h-12 rounded-md mr-3" />
                                            <div className="flex-grow">
                                                <p className="font-semibold">{part.name}</p>
                                                <p className="text-sm text-slate-400">Qty: {quantity}</p>
                                            </div>
                                            <p className="font-bold text-lg">AED {part.availability.find(a => a.stock > 0)?.price || 'N/A'}</p>
                                        </li>
                                    ))}
                                </ul>
                                <h4 className="font-bold mb-2 text-slate-200">Delivery Options:</h4>
                                <div className="space-y-2 mb-4">
                                    {report.deliveryOptions?.map(opt => (
                                        <div key={opt.type} onClick={() => setSelectedDelivery(opt)} className={`p-3 rounded-lg border-2 cursor-pointer flex justify-between items-center ${selectedDelivery?.type === opt.type ? 'border-orange-500 bg-orange-500/10' : 'border-slate-700'}`}>
                                            <div>
                                                <p className="font-semibold">{opt.type} Delivery</p>
                                                <p className="text-sm text-slate-400">Est. Arrival: {opt.time}</p>
                                            </div>
                                            <p className="font-bold text-lg">AED {opt.cost}</p>
                                        </div>
                                    ))}
                                </div>
                            </>
                        )}
                        
                        <div className="mt-4 pt-4 border-t border-slate-700 text-right">
                            <p className="text-sm text-slate-400">Labor: AED {report.laborCost}</p>
                            <p className="text-sm text-slate-400">Parts: AED {report.totalPartCost}</p>
                            {selectedDelivery && <p className="text-sm text-slate-400">Delivery: AED {selectedDelivery.cost}</p>}
                            <p className="text-xl font-bold text-white mt-1">Total: AED {report.laborCost + report.totalPartCost + (selectedDelivery?.cost || 0)}</p>
                        </div>
                        
                         <div className="flex gap-4 mt-6">
                            <button onClick={() => onUpdateStatus(job.id, 'Declined')} className="w-full bg-red-600 text-white font-bold py-3 rounded-xl hover:bg-red-500 transition">Decline</button>
                            <button onClick={handleApproval} className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-500 transition">Approve</button>
                        </div>
                    </div>
                )}
                
                {['Awaiting Parts', 'Parts Ordered', 'In Progress'].includes(job.status) && (
                    <>
                        <div className="bg-slate-800 p-4 rounded-xl mb-4">
                            <h3 className="text-lg font-bold mb-2">Job Status: <span className="text-orange-400">{job.status}</span></h3>
                            <p className="text-slate-400">
                                {job.status === 'Awaiting Parts' && 'Waiting for technician to order parts...'}
                                {job.status === 'Parts Ordered' && 'Parts are on the way to the technician.'}
                                {job.status === 'In Progress' && 'The technician is currently working on the repair.'}
                            </p>
                        </div>
                        {relatedOrders.map(order => {
                            const deliveryPerson = deliveryPeople.find(d => d.id === order.deliveryPersonId);
                            return (
                             <div key={order.id} className="bg-slate-800 p-4 rounded-xl">
                                <h4 className="font-bold mb-2">Part Order: {order.part.name}</h4>
                                <p>Status: <span className="font-semibold text-orange-400">{order.status}</span></p>
                                {deliveryPerson && <p className="text-sm text-slate-300">Delivery by: {deliveryPerson.name}</p>}
                                <div className="relative pt-4 pl-2">
                                    <div className="absolute left-[7px] top-5 h-full border-l-2 border-slate-600"></div>
                                    <div className="flex items-center gap-4 mb-3"><CheckCircleIcon className="w-5 h-5 text-green-500 bg-slate-900 z-10" /><span className="text-sm">Order Confirmed</span></div>
                                    <div className="flex items-center gap-4 mb-3"><CheckCircleIcon className={`w-5 h-5 z-10 ${['In Transit', 'Delivered'].includes(order.status) ? 'text-green-500 bg-slate-900' : 'text-slate-600 bg-slate-900'}`} /><span className={`text-sm ${!['In Transit', 'Delivered'].includes(order.status) && 'text-slate-500'}`}>In Transit</span></div>
                                    <div className="flex items-center gap-4"><CheckCircleIcon className={`w-5 h-5 z-10 ${order.status === 'Delivered' ? 'text-green-500 bg-slate-900' : 'text-slate-600 bg-slate-900'}`} /><span className={`text-sm ${order.status !== 'Delivered' && 'text-slate-500'}`}>Delivered to Technician</span></div>
                                </div>
                            </div>
                            )
                        })}
                    </>
                )}

                 {job.status === 'Awaiting Payment' && (
                    <div className="bg-slate-800 p-4 rounded-xl text-center">
                        <h3 className="text-xl font-bold mb-2">Job Complete!</h3>
                        <p className="text-slate-400 mb-4">Please review the final invoice and proceed with payment.</p>
                        <div className="text-4xl font-extrabold text-white mb-6">AED {job.totalCost}</div>
                        <button onClick={() => onUpdateStatus(job.id, 'Paid')} className="w-full bg-green-600 text-white font-bold py-4 rounded-xl hover:bg-green-500 transition">Pay Now</button>
                    </div>
                 )}

                 {job.status === 'Paid' && (
                    <div className="bg-slate-800 p-4 rounded-xl">
                        {reviewSubmitted ? (
                            <div className="text-center">
                                <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto mb-4" />
                                <h3 className="text-xl font-bold">Thank You!</h3>
                                <p className="text-slate-400">Your review has been submitted.</p>
                            </div>
                        ) : (
                            <>
                                <h3 className="text-xl font-bold text-center mb-2">How was your service?</h3>
                                <StarRatingInput rating={rating} setRating={setRating} />
                                <textarea
                                    value={comment}
                                    onChange={(e) => setComment(e.target.value)}
                                    placeholder="Add a comment..."
                                    className="w-full p-3 bg-slate-700 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-orange-500 outline-none"
                                    rows={3}
                                />
                                <button onClick={handleReviewSubmit} className="w-full mt-4 bg-orange-600 text-white font-bold py-3 rounded-xl hover:bg-orange-500 transition">Submit Review</button>
                            </>
                        )}
                    </div>
                )}
                
                <JobTimeline job={job} />

            </div>
            
            <CustomerTechnicianChatModal
                isOpen={showChat}
                onClose={() => setShowChat(false)}
                messages={messages}
                onSendMessage={onSendMessage}
                technicianName={technician.name}
            />
        </div>
    );
};

const CustomerHistoryPage: React.FC<{ jobs: ServiceJob[], technicians: Technician[] }> = ({ jobs, technicians }) => {
    return (
        <div className="p-4 bg-slate-900 text-white h-full">
            <h2 className="text-2xl font-bold mb-4">Service History</h2>
            <div className="space-y-4">
                {jobs.length > 0 ? jobs.map(job => {
                    const tech = technicians.find(t => t.id === job.technicianId);
                    return (
                        <div key={job.id} className="bg-slate-800 p-4 rounded-lg">
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="font-bold text-lg">{job.serviceType}</p>
                                    <p className="text-sm text-slate-400">with {tech?.name || 'N/A'}</p>
                                </div>
                                <div className="text-right">
                                    <p className="font-bold text-green-400">AED {job.totalCost}</p>
                                    <p className="text-xs text-slate-500">{job.requestTime}</p>
                                </div>
                            </div>
                            {job.review && (
                                <div className="mt-3 pt-3 border-t border-slate-700">
                                    <div className="flex items-center text-yellow-400">
                                        {[...Array(5)].map((_, i) => <StarIcon key={i} className={`w-5 h-5 ${i < job.review.rating ? 'text-yellow-400' : 'text-slate-600'}`} />)}
                                    </div>
                                    <p className="text-slate-300 mt-1 italic">"{job.review.comment}"</p>
                                </div>
                            )}
                        </div>
                    );
                }) : <p className="text-center text-slate-400 mt-8">No past jobs found.</p>}
            </div>
        </div>
    );
};

const CustomerProfilePage: React.FC<{ user: { name: string } }> = ({ user }) => (
    <div className="p-4 bg-slate-900 text-white h-full">
        <h2 className="text-2xl font-bold mb-4">My Profile</h2>
        <div className="bg-slate-800 p-6 rounded-lg text-center">
            <UserIcon className="w-24 h-24 mx-auto text-orange-400 bg-slate-700 p-4 rounded-full mb-4" />
            <h3 className="text-2xl font-bold">{user.name}</h3>
            <p className="text-slate-400">Dubai, UAE</p>
        </div>
    </div>
);

const CustomerBottomNav: React.FC<{ currentPage: CustomerPage, setPage: (page: CustomerPage) => void }> = ({ currentPage, setPage }) => {
    const navItems = [
        { page: 'HOME', icon: HomeIcon, label: 'Home' },
        { page: 'AI_ASSIST', icon: SparklesIcon, label: 'AI Assist' },
        { page: 'HISTORY', icon: ClockIcon, label: 'History' },
        { page: 'PROFILE', icon: UserIcon, label: 'Profile' }
    ] as const;

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 flex justify-around p-2 z-20">
            {navItems.map(item => (
                <button key={item.page} onClick={() => setPage(item.page)} className={`flex flex-col items-center w-1/4 p-2 rounded-lg transition-colors ${currentPage === item.page ? 'text-orange-500' : 'text-slate-400 hover:text-white'}`}>
                    <item.icon className="w-7 h-7 mb-1" />
                    <span className="text-xs font-semibold">{item.label}</span>
                </button>
            ))}
        </nav>
    );
};


// --- TECHNICIAN APP ---
interface TechnicianAppProps {
    user: Technician;
    jobs: ServiceJob[];
    parts: SparePart[];
    techChat: TechChatMessage[];
    customerTechMessages: CustomerTechMessage[];
    onSwitchRole: () => void;
    handleUpdateJob: (updatedJob: ServiceJob) => void;
    handleSendMessageToCommunity: (message: TechChatMessage) => void;
    handleSendMessageToCustomer: (message: CustomerTechMessage) => void;
    handleCreatePartOrder: (order: PartOrder) => void;
}
const TechnicianApp: React.FC<TechnicianAppProps> = ({ user, jobs, parts, techChat, customerTechMessages, onSwitchRole, handleUpdateJob, handleSendMessageToCommunity, handleSendMessageToCustomer, handleCreatePartOrder }) => {
    const [page, setPage] = useState<TechnicianPage>('DASHBOARD');
    const [activeJobId, setActiveJobId] = useState<string | null>(null);

    const activeJob = jobs.find(j => j.id === activeJobId);
    
    const navigateToJob = (jobId: string) => {
        setActiveJobId(jobId);
        setPage('JOB_DETAILS');
    };

    const myJobs = jobs.filter(j => j.technicianId === user.id && !['Completed', 'Declined', 'Paid'].includes(j.status));

    const renderContent = () => {
        switch (page) {
            case 'DASHBOARD': return <TechnicianDashboardPage user={user} jobs={myJobs} onJobSelect={navigateToJob} onSwitchRole={onSwitchRole} />;
            case 'JOB_DETAILS': return activeJob && <TechnicianJobDetailsPage job={activeJob} onUpdateJob={handleUpdateJob} onBack={() => setPage('DASHBOARD')} onNavigate={(p) => setPage(p)} parts={parts} messages={customerTechMessages} onSendMessage={handleSendMessageToCustomer} />;
            case 'REPORT_CREATION': return activeJob && <TechnicianReportCreationPage job={activeJob} onSubmitReport={handleUpdateJob} onBack={() => setPage('JOB_DETAILS')} onSearchParts={() => setPage('PARTS_SEARCH')} />;
            case 'PARTS_SEARCH': return activeJob && <TechnicianPartsSearchPage allParts={parts} onAddPartToReport={handleUpdateJob} activeJob={activeJob} onBack={() => setPage('REPORT_CREATION')} />;
            case 'DELIVERY_SELECTION': return activeJob && <TechnicianConfirmOrderPage job={activeJob} onConfirmOrder={handleCreatePartOrder} onBack={() => setPage('JOB_DETAILS')} />;
            case 'COMMUNITY': return <TechnicianCommunityChatPage user={user} messages={techChat} onSendMessage={handleSendMessageToCommunity} />;
            case 'PROFILE': return <TechnicianProfilePage user={user} />;
            default: return <div>Not Found</div>;
        }
    };
    
    return (
         <div className="w-full h-full flex flex-col bg-slate-900">
            <main className="flex-grow overflow-y-auto pb-20">
               {renderContent()}
            </main>
            <TechnicianBottomNav currentPage={page} setPage={setPage} />
         </div>
    );
};

const TechnicianDashboardPage: React.FC<{ user: Technician, jobs: ServiceJob[], onJobSelect: (jobId: string) => void; onSwitchRole: () => void; }> = ({ user, jobs, onJobSelect, onSwitchRole }) => (
    <div className="p-4 bg-slate-900 text-white h-full">
        <header className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Dashboard</h2>
            <SwitchRoleButton onSwitch={onSwitchRole} />
        </header>
        <div className="bg-slate-800 p-4 rounded-lg mb-4">
            <h3 className="text-xl font-bold">{user.name}</h3>
            <p className="text-slate-400">Welcome back! You have {jobs.length} active job{jobs.length !== 1 && 's'}.</p>
        </div>
        <h3 className="font-semibold text-lg mb-2">My Active Jobs</h3>
        <div className="space-y-3">
            {jobs.length > 0 ? jobs.map(job => (
                <div key={job.id} onClick={() => onJobSelect(job.id)} className="bg-slate-800 p-4 rounded-lg cursor-pointer hover:bg-slate-700 border-l-4 border-orange-500">
                    <div className="flex justify-between items-center">
                        <div>
                            <p className="font-bold text-lg">{job.serviceType}</p>
                            <p className="text-sm text-slate-400">{job.location}</p>
                        </div>
                        <span className="px-3 py-1 text-xs font-semibold rounded-full bg-orange-500/20 text-orange-400">{job.status}</span>
                    </div>
                     <p className="text-sm text-slate-300 mt-2 italic">"{job.problemSummary}"</p>
                </div>
            )) : <p className="text-center text-slate-400 mt-8">No active jobs. Great work!</p>}
        </div>
    </div>
);

const TechnicianJobDetailsPage: React.FC<{ job: ServiceJob; onUpdateJob: (job: ServiceJob) => void; onBack: () => void; onNavigate: (page: TechnicianPage) => void; parts: SparePart[]; messages: CustomerTechMessage[]; onSendMessage: (message: CustomerTechMessage) => void; }> = ({ job, onUpdateJob, onBack, onNavigate, parts, messages, onSendMessage }) => {
    const [showChat, setShowChat] = useState(false);
    
    const handleStatusUpdate = (status: ServiceJob['status']) => {
        let updatedJob = { ...job, status };
        if (status === 'Completed') {
            const totalPartCost = job.inspectionReport?.totalPartCost || 0;
            const laborCost = job.inspectionReport?.laborCost || 0;
            const deliveryCost = job.chosenDeliveryOption?.cost || 0;
            updatedJob.totalCost = totalPartCost + laborCost + deliveryCost;
        }
        onUpdateJob(updatedJob);
    };
    
    const technicianMessages = messages.filter(m => m.sender === 'technician' || m.sender === 'customer'); // Simple filter for demo

    return (
        <div className="p-4 bg-slate-900 text-white h-full">
            <header className="flex items-center mb-4">
                <button onClick={onBack} className="p-2 mr-2"><ArrowLeftIcon className="w-6 h-6"/></button>
                <h2 className="text-xl font-bold">Job Details</h2>
            </header>
            <div className="bg-slate-800 p-4 rounded-lg mb-4">
                <p><strong>Service:</strong> {job.serviceType}</p>
                <p><strong>Customer:</strong> {job.customerName}</p>
                <p><strong>Location:</strong> {job.location}</p>
                <p><strong>Status:</strong> <span className="font-bold text-orange-400">{job.status}</span></p>
                <p className="mt-2 text-slate-300 italic">"{job.problemSummary}"</p>
                 <button onClick={() => setShowChat(true)} className="mt-4 w-full bg-blue-600 text-white font-bold p-2 rounded-lg hover:bg-blue-500 transition">
                    Chat with Customer
                </button>
            </div>
            
            <div className="space-y-3">
                {job.status === 'Assigned' && <button onClick={() => handleStatusUpdate('En Route')} className="w-full p-3 bg-orange-600 rounded-lg font-bold">Start Travel</button>}
                {job.status === 'En Route' && <button onClick={() => handleStatusUpdate('Inspection')} className="w-full p-3 bg-orange-600 rounded-lg font-bold">Arrived & Start Inspection</button>}
                {job.status === 'Inspection' && <button onClick={() => onNavigate('REPORT_CREATION')} className="w-full p-3 bg-orange-600 rounded-lg font-bold">Create Inspection Report</button>}
                {job.status === 'Approved' && job.inspectionReport?.requiredParts.length === 0 && <button onClick={() => handleStatusUpdate('In Progress')} className="w-full p-3 bg-orange-600 rounded-lg font-bold">Begin Work</button>}
                {job.status === 'Approved' && job.inspectionReport?.requiredParts.length > 0 && <button onClick={() => onNavigate('DELIVERY_SELECTION')} className="w-full p-3 bg-orange-600 rounded-lg font-bold">Order Required Parts</button>}
                {job.status === 'Parts Ordered' && !job.partsReceived && <button onClick={() => onUpdateJob({...job, partsReceived: true, status: 'In Progress'})} className="w-full p-3 bg-blue-600 rounded-lg font-bold">Confirm Parts Received</button>}
                {job.status === 'In Progress' && <button onClick={() => handleStatusUpdate('Awaiting Payment')} className="w-full p-3 bg-green-600 rounded-lg font-bold">Mark as Complete</button>}
            </div>

            <CustomerTechnicianChatModal 
                isOpen={showChat} 
                onClose={() => setShowChat(false)} 
                messages={technicianMessages} 
                onSendMessage={(msg) => onSendMessage({...msg, sender: 'technician'})}
                technicianName={job.customerName} // Re-using modal, name is inverted
            />
        </div>
    );
};

const TechnicianReportCreationPage: React.FC<{ job: ServiceJob; onSubmitReport: (job: ServiceJob) => void; onBack: () => void; onSearchParts: () => void; }> = ({ job, onSubmitReport, onBack, onSearchParts }) => {
    const [report, setReport] = useState<Omit<InspectionReport, 'totalPartCost' | 'deliveryOptions'>>({
        faultSummary: job.inspectionReport?.faultSummary || '',
        estimatedFixTime: job.inspectionReport?.estimatedFixTime || '',
        laborCost: job.inspectionReport?.laborCost || 0,
        requiredParts: job.inspectionReport?.requiredParts || [],
    });
    
    const totalPartCost = report.requiredParts.reduce((sum, item) => sum + ((item.part.availability.find(a => a.stock > 0)?.price || 0) * item.quantity), 0);

    const handleNavigateToSearch = () => {
        const draftReport: InspectionReport = {
            ...report,
            totalPartCost,
            deliveryOptions: job.inspectionReport?.deliveryOptions,
        };
        // Save draft before navigating
        onSubmitReport({ ...job, inspectionReport: draftReport });
        onSearchParts();
    };

    const handleSubmit = () => {
        if (!report.faultSummary || !report.estimatedFixTime) {
            alert("Please fill out all fields.");
            return;
        }
        const deliveryOptions: DeliveryOption[] = [
            { type: 'Standard', time: '2-3 hours', cost: 15 },
            { type: 'Express', time: '45 mins', cost: 40 },
        ];
        
        const fullReport: InspectionReport = { ...report, totalPartCost, deliveryOptions };
        onSubmitReport({ ...job, inspectionReport: fullReport, status: 'Awaiting Approval' });
        onBack();
    };

    return (
        <div className="p-4 bg-slate-900 text-white h-full">
            <header className="flex items-center mb-4">
                <button onClick={onBack} className="p-2 mr-2"><ArrowLeftIcon className="w-6 h-6"/></button>
                <h2 className="text-xl font-bold">Create Report</h2>
            </header>
            <div className="space-y-4">
                 <input type="text" placeholder="Fault Summary (e.g., Compressor failed)" value={report.faultSummary} onChange={e => setReport({...report, faultSummary: e.target.value})} className="w-full p-3 bg-slate-800 rounded-lg" />
                 <input type="text" placeholder="Estimated Fix Time (e.g., 2 hours)" value={report.estimatedFixTime} onChange={e => setReport({...report, estimatedFixTime: e.target.value})} className="w-full p-3 bg-slate-800 rounded-lg" />
                 <input type="number" placeholder="Labor Cost (AED)" value={report.laborCost || ''} onChange={e => setReport({...report, laborCost: parseFloat(e.target.value) || 0})} className="w-full p-3 bg-slate-800 rounded-lg" />
            </div>
            <div className="my-4">
                <h3 className="font-bold text-lg mb-2">Required Parts ({report.requiredParts.length})</h3>
                <div className="space-y-2 mb-2">
                    {report.requiredParts.map(({part, quantity}) => (
                        <div key={part.id} className="bg-slate-800 p-2 rounded-lg flex justify-between items-center">
                            <span>{part.name} (x{quantity})</span>
                            <span>AED {part.availability.find(a => a.stock > 0)?.price || 'N/A'}</span>
                        </div>
                    ))}
                </div>
                <button onClick={handleNavigateToSearch} className="w-full p-3 bg-blue-600 rounded-lg font-semibold flex items-center justify-center gap-2"><PlusIcon className="w-5 h-5"/> Add Part from Search</button>
            </div>
            <div className="text-right font-bold text-xl my-4">
                Total Parts: AED {totalPartCost}
            </div>
             <button onClick={handleSubmit} className="w-full p-4 bg-green-600 rounded-lg font-bold">Submit Report to Customer</button>
        </div>
    );
};

const TechnicianPartsSearchPage: React.FC<{ allParts: SparePart[]; activeJob: ServiceJob; onAddPartToReport: (job: ServiceJob) => void; onBack: () => void; }> = ({ allParts, activeJob, onAddPartToReport, onBack }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isScanning, setIsScanning] = useState(false);
    const [showInStock, setShowInStock] = useState(false);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const filteredParts = allParts.filter(part =>
        (part.name.toLowerCase().includes(searchTerm.toLowerCase()) || part.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()))
        && (!showInStock || part.availability.some(a => a.stock > 0))
    );

    const handleAddPart = (part: SparePart) => {
        const existingReport = activeJob.inspectionReport || { requiredParts: [] };
        const existingPart = existingReport.requiredParts.find(p => p.part.id === part.id);
        
        let updatedParts;
        if (existingPart) {
            updatedParts = existingReport.requiredParts.map(p => p.part.id === part.id ? { ...p, quantity: p.quantity + 1 } : p);
        } else {
            updatedParts = [...(existingReport.requiredParts || []), { part, quantity: 1 }];
        }
        
        onAddPartToReport({ ...activeJob, inspectionReport: { ...activeJob.inspectionReport, requiredParts: updatedParts } as InspectionReport });
        onBack();
    };
    
    const handleAiScan = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            if (videoRef.current) videoRef.current.srcObject = stream;
            setIsScanning(true);
        } catch (err) {
            console.error("Camera error:", err);
            alert("Could not access camera.");
        }
    };

    const handleTakePictureForScan = async () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg');

            const stream = video.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            setIsScanning(false);
            
            try {
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                const base64Data = dataUrl.split(',')[1];
                const response = await ai.models.generateContent({
                    model: GEMINI_MODEL,
                    contents: {
                        parts: [
                            { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
                            { text: "Analyze this image of a spare part. Identify and extract the most prominent serial number or model number. Respond with only the number, nothing else." }
                        ]
                    },
                });
                const extractedNumber = response.text.trim();
                setSearchTerm(extractedNumber);
            } catch (error) {
                console.error("AI Scan Error:", error);
                alert("AI could not read the number. Please try again.");
            }
        }
    };
    
    if (isScanning) {
        return (
             <div className="absolute inset-0 bg-black z-30 flex flex-col items-center justify-center">
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover"></video>
                <canvas ref={canvasRef} className="hidden"></canvas>
                <div className="absolute top-4 left-4 text-white bg-black/50 p-2 rounded">Align part number in frame</div>
                 <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/50 flex justify-center items-center">
                    <button onClick={() => setIsScanning(false)} className="absolute left-4 p-3 bg-gray-600/80 rounded-full text-white">Cancel</button>
                    <button onClick={handleTakePictureForScan} className="p-4 bg-white rounded-full ring-4 ring-white/30"></button>
                </div>
            </div>
        );
    }
    
    return (
        <div className="p-4 bg-slate-900 text-white h-full flex flex-col">
            <header className="flex items-center mb-4 flex-shrink-0">
                <button onClick={onBack} className="p-2 mr-2"><ArrowLeftIcon className="w-6 h-6"/></button>
                <h2 className="text-xl font-bold">Search Parts</h2>
            </header>
            <div className="flex gap-2 mb-4 flex-shrink-0">
                <div className="relative flex-grow">
                    <MagnifyingGlassIcon className="w-5 h-5 text-slate-400 absolute top-1/2 left-3 -translate-y-1/2"/>
                    <input type="text" placeholder="Search by name or S/N" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full p-3 pl-10 bg-slate-800 rounded-lg" />
                </div>
                <button onClick={handleAiScan} className="p-3 bg-orange-600 rounded-lg"><CameraIcon className="w-6 h-6"/></button>
            </div>
            <div className="flex-shrink-0 mb-4">
                <label className="flex items-center gap-2 text-slate-300">
                    <input type="checkbox" checked={showInStock} onChange={e => setShowInStock(e.target.checked)} className="form-checkbox h-5 w-5 rounded bg-slate-700 border-slate-600 text-orange-600 focus:ring-orange-500" />
                    Show only "In Stock"
                </label>
            </div>
            <div className="flex-grow space-y-3 overflow-y-auto">
                {filteredParts.map(part => (
                    <div key={part.id} className="bg-slate-800 p-3 rounded-lg flex items-center">
                        <img src={part.imageUrl} alt={part.name} className="w-16 h-16 rounded-md mr-4"/>
                        <div className="flex-grow">
                            <p className="font-bold">{part.name}</p>
                            <p className="text-sm text-slate-400">{part.serialNumber}</p>
                            {part.availability.some(a => a.stock > 0) ? 
                                <span className="text-xs font-semibold text-green-400">In Stock</span> : 
                                <span className="text-xs font-semibold text-red-400">Out of Stock</span>
                            }
                        </div>
                        <button onClick={() => handleAddPart(part)} disabled={!part.availability.some(a => a.stock > 0)} className="p-2 bg-blue-600 rounded-lg disabled:bg-slate-700">
                            <PlusIcon className="w-6 h-6"/>
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

const TechnicianConfirmOrderPage: React.FC<{ job: ServiceJob; onConfirmOrder: (order: PartOrder) => void; onBack: () => void; }> = ({ job, onConfirmOrder, onBack }) => {
    const handleOrder = () => {
        const partsToOrder = job.inspectionReport?.requiredParts || [];
        partsToOrder.forEach(({ part, quantity }) => {
            const availableSupplier = part.availability.find(a => a.stock >= quantity);
            if (availableSupplier) {
                const newOrder: PartOrder = {
                    id: `order-${Date.now()}-${part.id}`,
                    part,
                    quantity,
                    technicianId: job.technicianId!,
                    jobId: job.id,
                    status: 'Pending',
                    orderTime: new Date().toLocaleTimeString(),
                    deliveryOption: job.chosenDeliveryOption!,
                    totalCost: availableSupplier.price * quantity + job.chosenDeliveryOption!.cost,
                    verificationCode: generateVerificationCode(),
                    pickupLocation: availableSupplier.partnerName,
                    deliveryLocation: job.location,
                    deliveryConfirmed: false,
                    partnerId: availableSupplier.partnerId,
                };
                onConfirmOrder(newOrder);
            }
        });
        onBack();
    };

    return (
        <div className="p-4 bg-slate-900 text-white h-full">
            <header className="flex items-center mb-4">
                <button onClick={onBack} className="p-2 mr-2"><ArrowLeftIcon className="w-6 h-6"/></button>
                <h2 className="text-xl font-bold">Confirm Part Order</h2>
            </header>
            <div className="bg-slate-800 p-4 rounded-lg">
                <p className="mb-4 text-slate-300">The customer has approved the following parts and delivery option. Please confirm to place the order.</p>
                <div className="divide-y divide-slate-700">
                    <div className="py-2">
                        <h3 className="font-bold text-lg mb-2 text-orange-400">Parts to Order:</h3>
                        <ul className="space-y-2 mb-4">
                            {job.inspectionReport?.requiredParts.map(({part, quantity}) => <li key={part.id} className="flex justify-between"><span>{part.name} (x{quantity})</span><span>from {part.availability.find(a=>a.stock>0)?.partnerName}</span></li>)}
                        </ul>
                    </div>
                    <div className="py-2">
                        <h3 className="font-bold text-lg mb-2 text-orange-400">Delivery Method:</h3>
                        <p className="flex justify-between"><span>{job.chosenDeliveryOption?.type} ({job.chosenDeliveryOption?.time})</span> <span>AED {job.chosenDeliveryOption?.cost}</span></p>
                    </div>
                </div>
                <button onClick={handleOrder} className="w-full mt-6 p-4 bg-green-600 rounded-lg font-bold hover:bg-green-500 transition">Place Order</button>
            </div>
        </div>
    );
};

const TechnicianCommunityChatPage: React.FC<{ user: Technician, messages: TechChatMessage[], onSendMessage: (message: TechChatMessage) => void; }> = ({ user, messages, onSendMessage }) => {
    const [input, setInput] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);
    
    const handleSend = () => {
        if (input.trim()) {
            onSendMessage({
                senderId: user.id,
                senderName: user.name,
                text: input,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            });
            setInput('');
        }
    };
    
    return (
        <div className="flex flex-col h-full bg-slate-900 text-white">
            <header className="p-4 flex-shrink-0 z-10 flex items-center bg-slate-900 border-b border-slate-700 shadow-md">
                 <h2 className="text-xl font-bold text-white flex items-center gap-2"><ChatBubbleLeftRightIcon className="w-6 h-6 text-orange-400" /> Community Chat</h2>
            </header>
            <div className="flex-grow p-4 space-y-4 overflow-y-auto">
                {messages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.senderId === user.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`p-3 rounded-xl max-w-[85%] ${msg.senderId === user.id ? 'bg-orange-600' : 'bg-slate-700'}`}>
                            {msg.senderId !== user.id && <p className="font-bold text-sm text-orange-300">{msg.senderName}</p>}
                            <p>{msg.text}</p>
                             <p className="text-xs text-right mt-1 opacity-70">{msg.timestamp}</p>
                        </div>
                    </div>
                ))}
                <div ref={chatEndRef}></div>
            </div>
            <div className="p-4 bg-slate-800 border-t border-slate-700">
                <div className="flex items-center gap-2 bg-slate-700 rounded-xl p-2">
                    <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSend()} placeholder="Type a message..." className="w-full bg-transparent text-white placeholder-slate-400 focus:ring-0 outline-none px-2" />
                    <button onClick={handleSend} disabled={!input.trim()} className="p-3 bg-orange-600 rounded-full text-white disabled:bg-slate-600"><PaperAirplaneIcon className="w-6 h-6" /></button>
                </div>
            </div>
        </div>
    );
};

const TechnicianProfilePage: React.FC<{ user: Technician }> = ({ user }) => (
    <div className="p-4 bg-slate-900 text-white h-full overflow-y-auto">
        <h2 className="text-2xl font-bold mb-4">My Profile</h2>
        <div className="bg-slate-800 p-4 rounded-lg text-center mb-4">
            <img src={user.photoUrl} alt={user.name} className="w-24 h-24 mx-auto rounded-full border-4 border-orange-500 mb-4"/>
            <h3 className="text-2xl font-bold">{user.name}</h3>
            <p className="text-slate-400">{user.specialization}</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg mb-4">
            <h4 className="font-bold text-lg mb-2">Details</h4>
            <p><strong>Experience:</strong> {user.experience} years</p>
            <p><strong>Vehicle:</strong> {user.vehicleType}</p>
            <p><strong>Service Area:</strong> {user.serviceArea}</p>
            <p><strong>Skills:</strong> {user.skills.join(', ')}</p>
        </div>
         <div className="bg-slate-800 p-4 rounded-lg">
            <h4 className="font-bold text-lg mb-2">Rewards</h4>
            <p className="text-2xl font-bold text-orange-400">{user.rewards.points} pts</p>
            <p>Level: <span className="font-semibold">{user.rewards.level}</span></p>
        </div>
    </div>
);

const TechnicianBottomNav: React.FC<{ currentPage: TechnicianPage, setPage: (page: TechnicianPage) => void }> = ({ currentPage, setPage }) => {
    const navItems = [
        { page: 'DASHBOARD', icon: HomeIcon, label: 'Dashboard' },
        { page: 'PARTS_SEARCH', icon: MagnifyingGlassIcon, label: 'Parts' },
        { page: 'COMMUNITY', icon: ChatBubbleLeftRightIcon, label: 'Community' },
        { page: 'PROFILE', icon: UserIcon, label: 'Profile' }
    ] as const;

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 flex justify-around p-2 z-20">
            {navItems.map(item => (
                <button key={item.page} onClick={() => setPage(item.page)} className={`flex flex-col items-center w-1/4 p-2 rounded-lg transition-colors ${currentPage.startsWith(item.page) ? 'text-orange-500' : 'text-slate-400 hover:text-white'}`}>
                    <item.icon className="w-7 h-7 mb-1" />
                    <span className="text-xs font-semibold">{item.label}</span>
                </button>
            ))}
        </nav>
    );
};


// --- PARTNER APP ---
interface PartnerAppProps {
    user: { name: string, id: string };
    orders: PartOrder[];
    parts: SparePart[];
    onSwitchRole: () => void;
    handleConfirmOrder: (order: PartOrder) => void;
    onUpdateStock: (partId: string, partnerId: string, newStock: number) => void;
}
const PartnerApp: React.FC<PartnerAppProps> = ({ user, orders, parts, onSwitchRole, handleConfirmOrder, onUpdateStock }) => {
    const [page, setPage] = useState<PartnerPage>('DASHBOARD');
    
    const myOrders = orders.filter(o => o.partnerId === user.id);
    const myParts = parts.map(p => ({
        ...p,
        availability: p.availability.filter(a => a.partnerId === user.id)
    })).filter(p => p.availability.length > 0);
    
    const renderContent = () => {
        switch (page) {
            case 'DASHBOARD': return <PartnerDashboardPage user={user} orders={myOrders} onConfirmOrder={handleConfirmOrder} onSwitchRole={onSwitchRole} />;
            case 'INVENTORY': return <PartnerInventoryPage user={user} parts={myParts} onUpdateStock={onUpdateStock} />;
            case 'PROFILE': return <PartnerProfilePage user={user} />;
        }
    };
    
    return (
        <div className="w-full h-full flex flex-col bg-slate-900">
            <main className="flex-grow overflow-y-auto pb-20">
               {renderContent()}
            </main>
            <PartnerBottomNav currentPage={page} setPage={setPage} />
         </div>
    );
};

const PartnerDashboardPage: React.FC<{ user: { name: string }, orders: PartOrder[], onConfirmOrder: (order: PartOrder) => void; onSwitchRole: () => void }> = ({ user, orders, onConfirmOrder, onSwitchRole }) => (
    <div className="p-4 bg-slate-900 text-white h-full">
        <header className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Partner Dashboard</h2>
            <SwitchRoleButton onSwitch={onSwitchRole} />
        </header>
        <h3 className="font-semibold text-lg mb-2">Pending Orders</h3>
        <div className="space-y-3">
            {orders.filter(o => o.status === 'Pending').map(order => (
                <div key={order.id} className="bg-slate-800 p-4 rounded-lg">
                    <p className="font-bold">{order.part.name} (x{order.quantity})</p>
                    <p className="text-sm text-slate-400">Order ID: {order.id}</p>
                    <button onClick={() => onConfirmOrder(order)} className="w-full mt-2 p-2 bg-green-600 rounded-lg font-bold">Prepare for Pickup</button>
                </div>
            ))}
        </div>
        <h3 className="font-semibold text-lg mt-6 mb-2">Ready for Pickup</h3>
        <div className="space-y-3">
             {orders.filter(o => o.status === 'Ready for Pickup' || o.status === 'Awaiting Pickup').map(order => (
                <div key={order.id} className="bg-slate-800 p-4 rounded-lg">
                    <p className="font-bold">{order.part.name} (x{order.quantity})</p>
                    <p className="text-sm text-slate-400">QR Code ready for scanning.</p>
                </div>
            ))}
        </div>
    </div>
);

const PartnerInventoryPage: React.FC<{ user: { id: string }, parts: SparePart[], onUpdateStock: (partId: string, partnerId: string, newStock: number) => void }> = ({ user, parts, onUpdateStock }) => {
    const handleStockChange = (partId: string, currentStock: number) => {
        const newStock = prompt(`Enter new stock for this part:`, currentStock.toString());
        if (newStock !== null && !isNaN(parseInt(newStock))) {
            onUpdateStock(partId, user.id, parseInt(newStock));
        }
    };

    return (
        <div className="p-4 bg-slate-900 text-white h-full">
            <h2 className="text-2xl font-bold mb-4">My Inventory</h2>
            <div className="space-y-3">
                {parts.map(part => (
                    <div key={part.id} className="bg-slate-800 p-3 rounded-lg flex items-center">
                        <img src={part.imageUrl} alt={part.name} className="w-16 h-16 rounded-md mr-4"/>
                        <div className="flex-grow">
                            <p className="font-bold">{part.name}</p>
                            <p className="text-sm text-slate-400">{part.serialNumber}</p>
                        </div>
                        <button onClick={() => handleStockChange(part.id, part.availability[0].stock)} className="text-center">
                            <p className="text-2xl font-bold">{part.availability[0].stock}</p>
                            <p className="text-xs text-slate-400">In Stock</p>
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

const PartnerProfilePage: React.FC<{ user: { name: string } }> = ({ user }) => (
     <div className="p-4 bg-slate-900 text-white h-full">
        <h2 className="text-2xl font-bold mb-4">Store Profile</h2>
        <div className="bg-slate-800 p-6 rounded-lg text-center">
            <BuildingStorefrontIcon className="w-24 h-24 mx-auto text-orange-400 bg-slate-700 p-4 rounded-full mb-4" />
            <h3 className="text-2xl font-bold">{user.name}</h3>
            <p className="text-slate-400">Dubai, UAE</p>
        </div>
    </div>
);

const PartnerBottomNav: React.FC<{ currentPage: PartnerPage, setPage: (page: PartnerPage) => void }> = ({ currentPage, setPage }) => {
     const navItems = [
        { page: 'DASHBOARD', icon: HomeIcon, label: 'Dashboard' },
        { page: 'INVENTORY', icon: ListBulletIcon, label: 'Inventory' },
        { page: 'PROFILE', icon: UserIcon, label: 'Profile' }
    ] as const;

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 flex justify-around p-2 z-20">
            {navItems.map(item => (
                <button key={item.page} onClick={() => setPage(item.page)} className={`flex flex-col items-center w-1/3 p-2 rounded-lg transition-colors ${currentPage === item.page ? 'text-orange-500' : 'text-slate-400 hover:text-white'}`}>
                    <item.icon className="w-7 h-7 mb-1" />
                    <span className="text-xs font-semibold">{item.label}</span>
                </button>
            ))}
        </nav>
    );
};

// --- DELIVERY APP ---
interface DeliveryAppProps {
    user: DeliveryPerson;
    orders: PartOrder[];
    onSwitchRole: () => void;
    onUpdateOrder: (order: PartOrder) => void;
}
const DeliveryApp: React.FC<DeliveryAppProps> = ({ user, orders, onSwitchRole, onUpdateOrder }) => {
    const [page, setPage] = useState<DeliveryPage>('DASHBOARD');
    const myActiveJob = orders.find(o => o.deliveryPersonId === user.id && o.status !== 'Delivered');
    
    const renderContent = () => {
        switch (page) {
            case 'DASHBOARD': return <DeliveryDashboardPage user={user} allOrders={orders} activeJob={myActiveJob} onUpdateOrder={onUpdateOrder} onSwitchRole={onSwitchRole} />;
            case 'PROFILE': return <DeliveryProfilePage user={user} />;
        }
    };
     return (
        <div className="w-full h-full flex flex-col bg-slate-900">
            <main className="flex-grow overflow-y-auto pb-20">
               {renderContent()}
            </main>
            <DeliveryBottomNav currentPage={page} setPage={setPage} />
         </div>
    );
};

const DeliveryDashboardPage: React.FC<{ user: DeliveryPerson, allOrders: PartOrder[], activeJob: PartOrder | undefined, onUpdateOrder: (order: PartOrder) => void; onSwitchRole: () => void }> = ({ user, allOrders, activeJob, onUpdateOrder, onSwitchRole }) => {
    const [enteredCode, setEnteredCode] = useState('');
    
    const handleAcceptJob = (orderId: string) => {
        const order = allOrders.find(o => o.id === orderId);
        if (order) {
            onUpdateOrder({ ...order, deliveryPersonId: user.id, status: 'Awaiting Pickup' });
        }
    };

    const handleConfirmPickup = () => {
        if (activeJob) {
            onUpdateOrder({ ...activeJob, status: 'In Transit' });
        }
    };

    const handleConfirmDelivery = () => {
        if (activeJob && enteredCode === activeJob.verificationCode) {
            onUpdateOrder({ ...activeJob, status: 'Delivered', deliveryConfirmed: true });
            setEnteredCode('');
        } else {
            alert('Invalid verification code.');
        }
    };

    return (
        <div className="p-4 bg-slate-900 text-white h-full">
            <header className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">Delivery Dashboard</h2>
                <SwitchRoleButton onSwitch={onSwitchRole} />
            </header>

            {activeJob ? (
                <div>
                    <h3 className="font-semibold text-lg mb-2">Active Delivery</h3>
                    <div className="bg-slate-800 p-4 rounded-lg">
                        <p className="font-bold">{activeJob.part.name}</p>
                        <p>Status: <span className="text-orange-400 font-semibold">{activeJob.status}</span></p>
                        <div className="my-4">
                           <LiveTrackingMap durationMinutes={parseInt(activeJob.deliveryOption.time) || 45} vehicleType={user.vehicleType === 'Van' ? 'van' : 'bike'} />
                        </div>

                        {activeJob.status === 'Awaiting Pickup' && (
                            <div className="text-center">
                                <p className="mb-2"><strong>Pickup From:</strong> {activeJob.pickupLocation}</p>
                                <button onClick={handleConfirmPickup} className="w-full p-3 bg-blue-600 rounded-lg font-bold flex items-center justify-center gap-2"><QrCodeIcon className="w-5 h-5"/> Simulate QR Scan & Confirm Pickup</button>
                            </div>
                        )}
                        {activeJob.status === 'In Transit' && (
                             <div>
                                <p className="mb-2"><strong>Deliver To:</strong> {activeJob.deliveryLocation}</p>
                                <p className="text-sm text-slate-400 mb-2">Enter code from technician to confirm delivery.</p>
                                <div className="flex gap-2">
                                    <input type="text" value={enteredCode} onChange={e => setEnteredCode(e.target.value)} placeholder="Verification Code" className="flex-grow p-3 bg-slate-700 rounded-lg"/>
                                    <button onClick={handleConfirmDelivery} className="p-3 bg-green-600 rounded-lg font-bold">Confirm</button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            ) : (
                <div>
                    <h3 className="font-semibold text-lg mb-2">Available Jobs</h3>
                    <div className="space-y-3">
                        {allOrders.filter(o => o.status === 'Ready for Pickup').map(order => (
                             <div key={order.id} className="bg-slate-800 p-4 rounded-lg">
                                <p className="font-bold">{order.part.name}</p>
                                <p className="text-sm">{order.pickupLocation} to {order.deliveryLocation}</p>
                                <p className="text-sm text-slate-400">Payout: AED {order.deliveryOption.cost}</p>
                                <button onClick={() => handleAcceptJob(order.id)} className="w-full mt-2 p-2 bg-green-600 rounded-lg font-bold">Accept Job</button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

const DeliveryProfilePage: React.FC<{ user: DeliveryPerson }> = ({ user }) => (
    <div className="p-4 bg-slate-900 text-white h-full">
        <h2 className="text-2xl font-bold mb-4">My Profile</h2>
        <div className="bg-slate-800 p-6 rounded-lg text-center">
            <img src={user.photoUrl} alt={user.name} className="w-24 h-24 mx-auto rounded-full border-4 border-orange-500 mb-4"/>
            <h3 className="text-2xl font-bold">{user.name}</h3>
            <p className="text-slate-400">{user.vehicleType}</p>
            <div className="flex items-center justify-center text-yellow-400 mt-2"><StarIcon className="w-6 h-6 mr-1"/> {user.rating}</div>
        </div>
    </div>
);

const DeliveryBottomNav: React.FC<{ currentPage: DeliveryPage, setPage: (page: DeliveryPage) => void }> = ({ currentPage, setPage }) => {
    const navItems = [
        { page: 'DASHBOARD', icon: HomeIcon, label: 'Dashboard' },
        { page: 'PROFILE', icon: UserIcon, label: 'Profile' }
    ] as const;

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 flex justify-around p-2 z-20">
            {navItems.map(item => (
                <button key={item.page} onClick={() => setPage(item.page)} className={`flex flex-col items-center w-1/2 p-2 rounded-lg transition-colors ${currentPage === item.page ? 'text-orange-500' : 'text-slate-400 hover:text-white'}`}>
                    <item.icon className="w-7 h-7 mb-1" />
                    <span className="text-xs font-semibold">{item.label}</span>
                </button>
            ))}
        </nav>
    );
};

// --- MAIN APP & ROLE SELECTION ---
const RoleSelectionScreen: React.FC<{ onSelectRole: (role: UserRole) => void }> = ({ onSelectRole }) => (
    <div className="w-full h-full flex flex-col justify-center items-center p-8 bg-gradient-to-br from-slate-900 to-gray-900 text-white">
        <ZerpiLogo3D className="w-64 h-auto mb-12" />
        <h2 className="text-2xl font-bold mb-2">Welcome to Zerpi</h2>
        <p className="text-slate-400 mb-8 text-center">Select your role to continue.</p>
        <div className="w-full max-w-sm space-y-4">
            <button onClick={() => onSelectRole('Customer')} className="w-full flex items-center p-4 bg-slate-800 rounded-lg text-left hover:bg-orange-600 transition-colors border border-slate-700">
                <UserIcon className="w-8 h-8 mr-4 text-orange-400"/>
                <div>
                    <h3 className="font-bold text-lg">Customer</h3>
                    <p className="text-sm text-slate-400">Request and track services.</p>
                </div>
            </button>
            <button onClick={() => onSelectRole('Technician')} className="w-full flex items-center p-4 bg-slate-800 rounded-lg text-left hover:bg-orange-600 transition-colors border border-slate-700">
                <WrenchScrewdriverIcon className="w-8 h-8 mr-4 text-orange-400"/>
                <div>
                    <h3 className="font-bold text-lg">Technician</h3>
                    <p className="text-sm text-slate-400">Manage jobs and order parts.</p>
                </div>
            </button>
            <button onClick={() => onSelectRole('Partner')} className="w-full flex items-center p-4 bg-slate-800 rounded-lg text-left hover:bg-orange-600 transition-colors border border-slate-700">
                <BuildingStorefrontIcon className="w-8 h-8 mr-4 text-orange-400"/>
                <div>
                    <h3 className="font-bold text-lg">Partner</h3>
                    <p className="text-sm text-slate-400">Manage part inventory and orders.</p>
                </div>
            </button>
            <button onClick={() => onSelectRole('Delivery')} className="w-full flex items-center p-4 bg-slate-800 rounded-lg text-left hover:bg-orange-600 transition-colors border border-slate-700">
                <TruckIcon className="w-8 h-8 mr-4 text-orange-400"/>
                <div>
                    <h3 className="font-bold text-lg">Delivery</h3>
                    <p className="text-sm text-slate-400">View and complete delivery jobs.</p>
                </div>
            </button>
        </div>
    </div>
);

const App: React.FC = () => {
    const [userRole, setUserRole] = useState<UserRole | null>(null);

    // --- STATE MANAGEMENT ---
    const [jobs, setJobs] = useState<ServiceJob[]>([]);
    const [technicians] = useState<Technician[]>(MOCK_TECHNICIANS);
    const [parts, setParts] = useState<SparePart[]>(MOCK_SPARE_PARTS);
    const [orders, setOrders] = useState<PartOrder[]>([]);
    const [techChat, setTechChat] = useState<TechChatMessage[]>(MOCK_TECH_CHAT);
    const [customerTechChat, setCustomerTechChat] = useState<CustomerTechMessage[]>(MOCK_CUSTOMER_TECH_CHAT);

    const currentUser = {
        'Customer': { name: 'Aisha Al-Futtaim' },
        'Technician': MOCK_TECHNICIANS[0],
        'Partner': { name: 'XYZ Auto Parts', id: 'partner-1' },
        'Delivery': MOCK_DELIVERY_PEOPLE[0],
    };

    // --- HANDLERS ---
    const handleCreateJob = (serviceType: string, problemSummary: string) => {
        const newJob: ServiceJob = {
            id: `job-${Date.now()}`,
            customerName: 'Aisha Al-Futtaim',
            serviceType,
            problemSummary,
            location: 'Al Barsha, Dubai',
            status: 'Requested',
            requestTime: new Date().toLocaleTimeString(),
            partOrderIds: [],
            partsReceived: false,
        };
        setJobs(prev => [...prev, newJob]);
    };

    const handleSelectTechnician = (jobId: string, technician: Technician) => {
        setJobs(prev => prev.map(job => job.id === jobId ? { ...job, technicianId: technician.id, status: 'Assigned' } : job));
        setTimeout(() => {
             setJobs(prev => prev.map(job => job.id === jobId ? { ...job, status: 'En Route' } : job));
        }, 2000);
    };
    
    const handleUpdateJobStatus = (jobId: string, status: ServiceJob['status']) => {
        setJobs(prev => prev.map(job => job.id === jobId ? { ...job, status } : job));
    };

    const handleUpdateJob = (updatedJob: ServiceJob) => {
         setJobs(prev => prev.map(job => job.id === updatedJob.id ? updatedJob : job));
    };

    const handleCancelJob = (jobId: string) => {
        setJobs(prev => prev.filter(job => job.id !== jobId));
    };

    const handleApproveJobWithDelivery = (jobId: string, deliveryOption: DeliveryOption) => {
         setJobs(prev => prev.map(job => job.id === jobId ? { ...job, status: 'Approved', chosenDeliveryOption: deliveryOption } : job));
    };

    const handleCreatePartOrder = (order: PartOrder) => {
        setOrders(prev => [...prev, order]);
        setJobs(prev => prev.map(job => job.id === order.jobId ? { ...job, status: 'Parts Ordered', partOrderIds: [...job.partOrderIds, order.id] } : job));
    };
    
    const handleUpdateOrder = (updatedOrder: PartOrder) => {
         setOrders(prev => prev.map(order => order.id === updatedOrder.id ? updatedOrder : order));
    };
    
    const handlePartnerConfirmsOrder = (orderToConfirm: PartOrder) => {
        // 1. Update order status
        handleUpdateOrder({...orderToConfirm, status: 'Ready for Pickup'});

        // 2. Deduct stock
        handleUpdateStock(orderToConfirm.part.id, orderToConfirm.partnerId, -orderToConfirm.quantity);
    }

    const handleUpdateStock = (partId: string, partnerId: string, quantityChange: number) => {
        setParts(prevParts => prevParts.map(part => {
            if (part.id === partId) {
                return {
                    ...part,
                    availability: part.availability.map(avail => {
                        if (avail.partnerId === partnerId) {
                            return { ...avail, stock: avail.stock + quantityChange };
                        }
                        return avail;
                    })
                };
            }
            return part;
        }));
    };
    
     const handleJobReview = (jobId: string, rating: number, comment: string) => {
        setJobs(prev => prev.map(job => job.id === jobId ? { ...job, review: { rating, comment } } : job));
    };
    
    const handleSendMessageToCommunity = (message: TechChatMessage) => {
        setTechChat(prev => [...prev, message]);
    };
    
    const handleSendMessageToTech = (message: CustomerTechMessage) => {
         setCustomerTechChat(prev => [...prev, message]);
    };


    const renderAppByRole = () => {
        if (!userRole) return <RoleSelectionScreen onSelectRole={setUserRole} />;
        
        const switchRoleHandler = () => setUserRole(null);

        switch (userRole) {
            case 'Customer':
                return <CustomerApp 
                    user={currentUser.Customer}
                    jobs={jobs}
                    technicians={technicians}
                    orders={orders}
                    deliveryPeople={MOCK_DELIVERY_PEOPLE}
                    customerTechMessages={customerTechChat}
                    onSwitchRole={switchRoleHandler}
                    handleCreateJob={handleCreateJob}
                    handleSelectTechnician={handleSelectTechnician}
                    handleUpdateJobStatus={handleUpdateJobStatus}
                    handleJobReview={handleJobReview}
                    handleCancelJob={handleCancelJob}
                    handleApproveJobWithDelivery={handleApproveJobWithDelivery}
                    handleSendMessageToTech={handleSendMessageToTech}
                />;
            case 'Technician':
                 return <TechnicianApp 
                    user={currentUser.Technician}
                    jobs={jobs}
                    parts={parts}
                    techChat={techChat}
                    customerTechMessages={customerTechChat}
                    onSwitchRole={switchRoleHandler}
                    handleUpdateJob={handleUpdateJob}
                    handleSendMessageToCommunity={handleSendMessageToCommunity}
                    handleSendMessageToCustomer={handleSendMessageToTech}
                    handleCreatePartOrder={handleCreatePartOrder}
                />;
            case 'Partner':
                return <PartnerApp
                    user={currentUser.Partner}
                    orders={orders}
                    parts={parts}
                    onSwitchRole={switchRoleHandler}
                    handleConfirmOrder={handlePartnerConfirmsOrder}
                    onUpdateStock={(partId, partnerId, newStock) => handleUpdateStock(partId, partnerId, newStock - parts.find(p=>p.id===partId)?.availability.find(a=>a.partnerId===partnerId)!.stock!)}
                />;
            case 'Delivery':
                 return <DeliveryApp
                    user={currentUser.Delivery}
                    orders={orders}
                    onSwitchRole={switchRoleHandler}
                    onUpdateOrder={handleUpdateOrder}
                 />;
            default:
                return <RoleSelectionScreen onSelectRole={setUserRole} />;
        }
    };

    return (
        <div className="w-full h-screen font-sans">
            {renderAppByRole()}
        </div>
    );
};

export default App;
