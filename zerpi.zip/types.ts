// types.ts

export type UserRole = 'Customer' | 'Technician' | 'Partner' | 'Delivery';

// Customer App Types
export type CustomerPage = 'SPLASH' | 'HOME' | 'AI_ASSIST' | 'JOB_TRACKING' | 'HISTORY' | 'PROFILE' | 'TECHNICIAN_SELECTION';

export interface ServiceJob {
  id: string;
  customerName: string;
  serviceType: string;
  problemSummary: string;
  location: string;
  status: 'Requested' | 'Assigned' | 'En Route' | 'Inspection' | 'Awaiting Approval' | 'Approved' | 'Awaiting Parts' | 'Parts Ordered' | 'In Progress' | 'Completed' | 'Declined' | 'Awaiting Payment' | 'Paid';
  technicianId?: string;
  requestTime: string;
  totalCost?: number;
  partOrderIds: string[];
  inspectionReport?: InspectionReport;
  review?: {
    rating: number;
    comment: string;
  };
  chosenDeliveryOption?: {
    type: string;
    time: string;
    cost: number;
  };
  partsReceived: boolean;
}
export interface AiChatMessage {
  sender: 'user' | 'ai';
  text: string;
  image?: string;
  data?: any; // To hold structured data from AI
}

export interface CustomerTechMessage {
    sender: 'customer' | 'technician';
    text: string;
    timestamp: string;
}

// Technician App Types
export type TechnicianPage = 'DASHBOARD' | 'JOB_DETAILS' | 'PARTS_SEARCH' | 'COMMUNITY' | 'PROFILE' | 'REPORT_CREATION' | 'HISTORY' | 'DELIVERY_SELECTION';
export interface Technician {
  id: string;
  name: string;
  photoUrl: string;
  distance: string;
  eta?: string;
  rating: number;
  specialization: string;
  vehicleType: string;
  badgeNumber: string;
  skills: string[];
  experience: number;
  serviceArea: string;
  reviews: { author: string; comment: string; rating: number }[];
  rewards: {
    points: number;
    level: string;
  };
}

export interface DeliveryOption {
    type: string;
    time: string;
    cost: number;
}

export interface InspectionReport {
    faultSummary: string;
    estimatedFixTime: string;
    laborCost: number;
    requiredParts: { part: SparePart; quantity: number }[];
    totalPartCost: number;
    imageUrl?: string;
    deliveryOptions?: DeliveryOption[];
}
export interface TechChatMessage {
    senderId: string;
    senderName: string;
    text: string;
    timestamp: string;
}


// Partner App Types
export type PartnerPage = 'DASHBOARD' | 'INVENTORY' | 'PROFILE';
export interface SparePart {
    id: string;
    name: string;
    imageUrl: string;
    serialNumber: string;
    availability: { partnerId: string; partnerName: string; partnerLocation: string, stock: number, price: number }[];
}


// Delivery App Types
export type DeliveryPage = 'DASHBOARD' | 'JOB_DETAILS' | 'PROFILE';
export interface PartOrder {
  id: string;
  part: SparePart;
  quantity: number;
  technicianId: string;
  jobId: string;
  status: 'Pending' | 'Ready for Pickup' | 'Awaiting Pickup' | 'In Transit' | 'Delivered';
  orderTime: string;
  deliveryOption: {
    type: string;
    time: string;
    cost: number;
  };
  totalCost: number;
  verificationCode: string;
  pickupLocation: string;
  deliveryLocation: string;
  deliveryConfirmed: boolean;
  partnerId: string;
  deliveryPersonId?: string;
}

export interface DeliveryPerson {
  id: string;
  name: string;
  photoUrl: string;
  vehicleType: string;
  rating: number;
}